import { Component, OnInit } from '@angular/core';
import { UseruserDto } from 'src/app/model/attendees/UseruserDto'; // Your existing UseruserDto
import { AdminServiceService } from 'src/app/services/admin-service.service';
import { EventService } from 'src/app/services/event.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { Event } from 'src/app/model/attendees/event';
import { ShowAllTicketsDto } from 'src/app/model/show-all-tickets-dto';
type UserWithEditing = UseruserDto & { isEditing: boolean };

@Component({
  selector: 'app-admincontrol',
  templateUrl: './admincontrol.component.html',
  styleUrls: ['./admincontrol.component.css'],
})
export class AdmincontrolComponent implements OnInit {
  users: UserWithEditing[] = []; // Stores the complete list of users
  filteredUsers: UserWithEditing[] = []; // Stores the users currently displayed (after filtering)
  searchTerm: string = ''; // Binds to the search input field
user: any;

  constructor(private ser: AdminServiceService, private uServ: UserServiceService,private eServ:EventService) {}

  ngOnInit(): void {
    this.getAllUser();
    this.getAllEvents();
  }

  status: any;

  public getAllUser(): void {
    this.ser.getAllUser().subscribe({
      next: (us: UseruserDto[]) => {
        this.users = us.map((user) => {
          const userWithEdit = user as UserWithEditing;
          userWithEdit.isEditing = false;
          return userWithEdit;
        });
        this.filteredUsers = [...this.users]; // Initialize filteredUsers with all users
      },
      error: (err) => {
        console.error('Error fetching users:', err);
      },
    });
  }


  public searchUser(): void {
    if (!this.searchTerm) {
      this.filteredUsers = [...this.users]; // If search term is empty, show all users
      return;
    }
   
    this.filteredUsers = this.users.filter((user) =>
      user.userId.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  public deleteUser(userId: string): void {

    if (confirm('Are you sure you want to delete this user?')) {
      this.ser.deleteUser(userId).subscribe({
        next: (response) => {
          this.status = response; // Store the response if you need it
          this.getAllUser(); // Re-fetch all users to ensure data consistency
        },
        error: (err) => {
          this.status = err; // Store the error response if needed
          console.error('Error deleting user:', err);
        },
      });
    }
  }

  public enableEdit(user: UserWithEditing): void {
    // Disable editing for all other users
    this.users.forEach((u) => {
      if (u.userId !== user.userId) {
        u.isEditing = false;
      }
    });
    user.isEditing = true;
  }

  public updateUser(user: UserWithEditing): void {
    this.uServ.updateUser(user.userId, user).subscribe({
      next: (p) => {
        user.isEditing = false; // Exit edit mode on successful update
        console.log('User updated successfully:', p);
      },
      error: (err) => {
        console.error('Error updating user:', err);
      },
    });
  }


  events:Event[]=[];
  filteredEvents: Event[] = []; // Stores events displayed after filtering
  eventSearchTerm: string = ''; // Binds to the search input field for events
  public getAllEvents(): void {
    this.eServ.getAllEvents().subscribe({
      next: (e: Event[]) => {
        this.events = e;
        this.filteredEvents = [...this.events]; // <--- THIS IS THE CRUCIAL LINE TO ADD/FIX
      },
      error: (err) => {
        console.error('Error fetching events:', err);
      }
    });
  }
  public searchEvents(): void {
    if (!this.eventSearchTerm) {
      this.filteredEvents = [...this.events]; // If search term is empty, show all events
      return;
    }
    const lowerCaseSearchTerm = this.eventSearchTerm.toLowerCase();
    this.filteredEvents = this.events.filter(event =>
      event.eventId.toLowerCase().includes(lowerCaseSearchTerm) ||
      event.name.toLowerCase().includes(lowerCaseSearchTerm) ||
      event.location.toLowerCase().includes(lowerCaseSearchTerm) || // Example: search by location too
      event.category.toLowerCase().includes(lowerCaseSearchTerm)    // Example: search by category
    );
  }
  public deleteEvent(id:string):void{
    if(confirm("Are you want dele this event ")){
      this.ser.deleteEvent(id).subscribe((res)=>this.status=res);

    }
  }

  isPast(date: string | Date): boolean {
    const inputDate = new Date(date);
    const currentDate = new Date();
    return inputDate < currentDate;
  }
  
  activeTab: 'users' | 'events' | 'tickets' ='users'; // Default to 'users'
  showTab(tab: 'users' | 'events' | 'tickets'): void {
    this.activeTab = tab;
  }

  eventId:string="";
  enable:boolean=false;
  tickets:ShowAllTicketsDto[]=[];
  checkevent(id:string):boolean{
       if(this.events.some(event => event.eventId === id)){
        return true;
       }
       return false;
  }
  searchTickets(): void {
    console.log('Searching tickets for event ID:', this.eventId);
  
    this.ser.getAllTickets(this.eventId).subscribe({
      next: (tickets) => {
        this.tickets = tickets;
        this.enable = true;
      },
      error: (err) => {
        console.error('Error fetching tickets:', err);
        this.enable = false;
      }
    });
  }
  

  deleteTicket(id:string):void{
    if(confirm("Are you sure to delete this ticket")){
      this.ser.deleteTicket(id).subscribe((del)=>{
        alert("Successfully deleyted");
        window.location.reload();
      })
      
    }

  }

}