import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EventPageComponent } from './event-page/event-page.component';
import { EventPage2Component } from './component/EventPage/event-page2/event-page2.component';
import { HomepageComponent } from './component/homepage/homepage.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { PaymentMainComponent } from './component/EventPage/payment-main/payment-main.component';
import { AllAttendeesComponent } from './component/all-attendees/all-attendees.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { FeedbackPageComponent } from './component/feedback-page/feedback-page.component';
import { EventCreateComponent } from './component/EventPage/event-create/event-create.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ShareTicketComponent } from './component/EventPage/share-ticket/share-ticket.component';
import { CancelTicketComponent } from './component/EventPage/cancel-ticket/cancel-ticket.component';

import { NgbDropdownModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { AllEventsComponent } from './component/all-events/all-events.component';
import { FooterComponent } from './component/footer/footer.component';
import { HomeNavbarComponent } from './component/home-navbar/home-navbar.component';
import { SignupComponent } from './component/signup/signup.component';
import { ViewDetailsComponent } from './component/view-details/view-details.component';
import { SignupNavbarComponent } from './component/signup-navbar/signup-navbar.component';
import { LoginComponent } from './component/login/login.component';
import { NotificationComponent } from './component/notification/notification.component';
import { ViewProfileComponent } from './component/view-profile/view-profile.component';
import { YourEventsComponent } from './component/your-events/your-events.component';
import { EventUpdateComponent } from './component/EventPage/event-update/event-update.component';
import { AttendeesComponent } from './component/attendees/attendees.component';
import { ForgotpasswordComponent } from './component/forgotpassword/forgotpassword.component';
import { ChangepasswordComponent } from './component/changepassword/changepassword.component';
import { MembershipComponent } from './component/membership/membership.component';
import { AdmincontrolComponent } from './admincontrol/admincontrol.component';



@NgModule({
  declarations: [
    AppComponent,
    EventPageComponent,
    EventPage2Component,
    HomepageComponent,
    PaymentMainComponent,
    AllAttendeesComponent,
    NotFoundComponent,
    FeedbackPageComponent,
    EventCreateComponent,
    ShareTicketComponent,
    CancelTicketComponent,
    AboutUsComponent,
    AllEventsComponent,
    FooterComponent,
    HomeNavbarComponent,
    SignupComponent,
    ViewDetailsComponent,
    SignupNavbarComponent,
    LoginComponent,
    NotificationComponent,
    ViewProfileComponent,
    YourEventsComponent,
    EventUpdateComponent,
    AttendeesComponent,
    ForgotpasswordComponent,
    ChangepasswordComponent,
    MembershipComponent,
    AdmincontrolComponent
  ],
  imports: [
    NgbDropdownModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
