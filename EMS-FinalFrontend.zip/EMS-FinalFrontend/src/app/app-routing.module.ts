import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EventPage2Component } from './component/EventPage/event-page2/event-page2.component';
import { HomepageComponent } from './component/homepage/homepage.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { FeedbackPageComponent } from './component/feedback-page/feedback-page.component';
import { LoginComponent } from './component/login/login.component';
import { AllEventsComponent } from './component/all-events/all-events.component';
import { FooterComponent } from './component/footer/footer.component';
import { AllAttendeesComponent } from './component/all-attendees/all-attendees.component';
import { HomeNavbarComponent } from './component/home-navbar/home-navbar.component';
import { SignupComponent } from './component/signup/signup.component';
import { ViewProfileComponent } from './component/view-profile/view-profile.component';
import { ViewDetailsComponent } from './component/view-details/view-details.component';
import { YourEventsComponent } from './component/your-events/your-events.component';
import { NotificationComponent } from './component/notification/notification.component';
import { EventCreateComponent } from './component/EventPage/event-create/event-create.component';
import { EventUpdateComponent } from './component/EventPage/event-update/event-update.component';
import { AttendeesComponent } from './component/attendees/attendees.component';
import { ForgotpasswordComponent } from './component/forgotpassword/forgotpassword.component';
import { ChangepasswordComponent } from './component/changepassword/changepassword.component';
import { AdmincontrolComponent } from './admincontrol/admincontrol.component';

const routes: Routes = [
  // {
  //   path: '',
  //   component: HomepageComponent
  // }, 
  {
    path:'',
    component:LoginComponent
  }
  ,
  {
    path:'homepage',
    component:HomepageComponent
  },
  {
    path: 'event/:eventid',
    component: EventPage2Component,
  },
  {
    path: 'not-found',
    component: NotFoundComponent
  }, {
    path: 'event/:eventId/feedback',
    component: FeedbackPageComponent
  },
  // {
  //   path: '**',
  //   redirectTo: 'not-found'
  // },
  {
    path:"all-events",
    component:AllEventsComponent
  },{
    path:"footer",
    component:FooterComponent
  },{
    path:"allattendees",
    component:AllAttendeesComponent
  },{
    path:"homenav",
    component:HomeNavbarComponent
  },{
    path:"signup",
    component:SignupComponent
  },{
    path:"view-profile",
    component:ViewProfileComponent
  },{
    path:"view-details",
    component:ViewDetailsComponent
  },{
    path:"your-events",
    component:YourEventsComponent
  },{
    path:"notification",
    component:NotificationComponent
  },{
    path:"createevent",
    component:EventCreateComponent
  },
  {
    path:"updateevent/:p1",
    component:EventUpdateComponent
  },{
    path:"attendees/:eventId",
    component:AttendeesComponent
  },{
    path:"forgot",
    component:ForgotpasswordComponent

  },{
    path:"changepassword/:userId",
    component:ChangepasswordComponent
  },
  {
    path:'admin',
    component:AdmincontrolComponent

  },
  {
      path: '**',
      redirectTo: 'not-found'
    }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
