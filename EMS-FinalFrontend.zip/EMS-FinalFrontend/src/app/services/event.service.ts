import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Eventdto } from '../model/eventdto';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  url: String = "http://localhost:9091/event/";

  constructor(private http: HttpClient) { }

  // public showAllEvents():Observable<any>{
  //   return this.http.get<any>(this.url +"/getallevents");
  // }

  // public getProducts(): Observable<Product[]> {
  //   return this.client.get<Product[]>(this.url + "/geteventbyid/{id}");
  // }



  public addEvent(eventData: any, file: File): Observable<any> {
    let formData = new FormData();

    formData.append('e', new Blob([JSON.stringify(eventData)], { type: 'application/json' }));

    formData.append('file', file);

    return this.http.post(`${this.url}addevent`, formData);
  }


  public updateEvent(eventId: string, eventData: any, file?: File): Observable<any> {
    const formData = new FormData();
    formData.append('event', new Blob([JSON.stringify(eventData)], { type: 'application/json' }));
    if (file) {
      formData.append('file', file);
    }
    return this.http.put(`${this.url}updateevent/${eventId}`, formData);
  }


  public getAllEvents(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}getallevents`, { responseType: 'json' });
  }


  public getEventById(id: string): Observable<Eventdto> {
    return this.http.get<Eventdto>(`${this.url}geteventbyid/${id}`);
  }

  // public getEventsByOrganizerId(orgId: string): Observable<Eventdto[]> {
  //   return this.http.get<any>(`${this.url}geteventbyorganizer/${orgId}`);
  // }


  public isEventExpired(eventId: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.url}expired/${eventId}`);
  }


  public validateEventId(eventId: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.url}validate/${eventId}`);
  }


  public getEventsByCategory(category: string): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}geteventbycategory/${category}`);
  }

  public getEventsByOrganizer(orgId: string): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}geteventbyorganizer/${orgId}`);
  }

  public getEventsByAmount(amount: number): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}geteventamountlessthan/${amount}`);
  }

  public getEventByUserId(id: String): Observable<any> {
    return this.http.get<any>(this.url + "geteventbyuserid/" + id);
  }

  // public getEventByOrganizerId(id: String): Observable<any> {
  //   return this.http.get<any>(this.url + "/geteventbyorganizer/" + id);
  // }

  // public updateEvent(eventId: string, eventDto: Eventdto): Observable<Eventdto> {
  //   return this.http.put<Eventdto>(`${this.url}updateevent/${eventId}`, eventDto);
  // }


  public deleteById(id: string): Observable<any> {
    return this.http.delete(`${this.url}deleteeventbyid/${id}`);
  }


  public checkStartedEvent(eventId: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.url}checkeventstart/${eventId}`);
  }


  public getEventsByLocation(location: string): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}geteventbylocation/${location}`);
  }


  public getEventByDate(date: string): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}geteventbydate/${date}`);
  }

  // --- Sorting Endpoints ---

  public sortByEventName(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventname`);
  }

  public sortByEventStartDate(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventstartdate`);
  }


  public sortByEventAmount(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventamount`);
  }


  public sortByEventCategory(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventcategory`);
  }


  public sortByEventMaxCount(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventmaxcount`);
  }

  public sortByEventEndDate(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventenddate`);
  }


  public sortByEventLocation(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventlocation`);
  }


  public sortByEventRegDate(): Observable<Eventdto[]> {
    return this.http.get<Eventdto[]>(`${this.url}sortbyeventregdate`);
  }



}
