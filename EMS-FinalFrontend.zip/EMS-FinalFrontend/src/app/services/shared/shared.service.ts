import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

const STORAGE_KEY = 'attendeeId'; // ✅ Move this above the decorator

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private attendeeIdSubject: BehaviorSubject<string | null>;
  attendeeId$;

  constructor() {
    const storedId = localStorage.getItem(STORAGE_KEY);
    this.attendeeIdSubject = new BehaviorSubject<string | null>(storedId);
    this.attendeeId$ = this.attendeeIdSubject.asObservable(); 
  }

  // ✅ Observable to subscribe to
  // attendeeId$ = this.attendeeIdSubject.asObservable();

  // ✅ Set and persist the attendee ID
  setAttendeeId(id: string) {
    localStorage.setItem(STORAGE_KEY, id);
    this.attendeeIdSubject.next(id);
  }

  // ✅ Get the current value
  getAttendeeId(): string | null {
    return this.attendeeIdSubject.getValue();
  }

  // ✅ Clear the ID
  clearAttendeeId() {
    localStorage.removeItem(STORAGE_KEY);
    this.attendeeIdSubject.next(null);
  }
}
