import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private url: string = "http://localhost:9091/notifications/";
 
  constructor(private http: HttpClient) {}
 
  public getNotificationById(userId: string): Observable<any> {
    return this.http.get<any>(this.url+"getNotificationByAttendeeId/"+userId);
  }
 
  public markAsRead(notificationId: string): Observable<any> {
    return this.http.put(this.url+notificationId+'/read',null);
  }

  public notificationDelete(notificationId: string): Observable<any> {
    return this.http.delete(`${this.url}delete/${notificationId}`);
  }
}
