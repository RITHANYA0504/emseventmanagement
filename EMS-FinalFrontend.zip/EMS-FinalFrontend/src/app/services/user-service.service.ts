import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of } from 'rxjs';
import { User } from '../model/attendees/User';
import { UseruserDto } from '../model/attendees/UseruserDto';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  url:string="http://localhost:9091/user";
  constructor(private h: HttpClient) { }
 

  public signUp(user:User):Observable<any>{
    return this.h.post<any>(this.url+"/signup",user,{responseType:'json'}).pipe(
      catchError((error: HttpErrorResponse) => {
        return of({ errorMsg: error.error?.errorMsg || 'SignUp failed' });
      })
    );
  }

  public login(name: string, password: string): Observable<any> {
    const params = new HttpParams().set('name', name).set('password', password);
    return this.h.get<any>(`${this.url}/login`, { params }).pipe(
      catchError((error: HttpErrorResponse) => {
        return of({ errorMsg: error.error?.errorMsg || 'Login failed' });
      })
    );
  }
  
 public getAllAttendees(id:string):Observable<any>{
  return this.h.get<any>(this.url+"/getattendeebyeventid/"+id);
 }

 public getUser(id:string):Observable<any>{
  return this.h.get<any>(this.url+"/finduserbyid/"+id);
 }

public updateUser(id:string,user:UseruserDto):Observable<any>{
  return this.h.put(this.url+"/updateaccount/"+id,user,{responseType:'json'});
}

public checkMemberShip(id:string):Observable<any>{
  return this.h.get<any>(this.url+"/checkmembership/"+id);
}

public addPreference(userId: string, eventId: string): Observable<any> {
  return this.h.post(`${this.url}/addpreference/${userId}/${eventId}`, null, { responseType: 'text' });
}
 
public getPreference(userId: string): Observable<any> {
  return this.h.get(`${this.url}/getpreference/${userId}`);
}
 
public removePreference(userId:string, eventId:string):Observable<any>{
  return this.h.delete(`${this.url}/removePreference/${userId}/${eventId}`,{responseType:'text'});
}


public getAttendeeByEvent(id:string):Observable<any>{
  return this.h.get<any>(`${this.url}/getattendeebyeventid/${id}`);
}

public sendEmail(name: string, email: string, number: string): Observable<any> {
  const params = new HttpParams()
    .set('userName', name)
    .set('email', email)
    .set('number', number);
  return this.h.get<any>(this.url + "/forgotpassword", { params }).pipe(
    catchError((error: HttpErrorResponse) => {
      return of({ errorMsg: error.error?.errorMsg || 'failed' });
    }));
}
public updatePassword(userId: string, password: string): Observable<any> {
  const params = new HttpParams()
    .set('id', userId)
    .set('password', password);
 
  return this.h.put<any>(this.url + "/changepassword", null, {
    params: params,
    responseType: 'json'
  }).pipe(
    catchError((error: HttpErrorResponse) => {
      return of({ errorMsg: error.error?.errorMsg || 'failed' });
    })
  );
}
 
 
 
public addMembership(userId:string):Observable<any>{
  return this.h.post(`${this.url}/addmembership/${userId}`,{responseType:'text'});
}
}

