import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TicketRequest } from '../model/ticket-request';
import { TicketResponse } from '../model/ticket-response';
import { TicketShare } from '../model/ticket-share';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  url:String ="http://localhost:9091/ticket/";
  
    constructor(private http:HttpClient) { }
  

    public getBookingStatus(ticketid:string): Observable<any> {
      return this.http.get(`${this.url}getbookingstatus/${ticketid}`,{ responseType: 'text' });
    }
    
    public getTicketIdByEventAndAttendee(eventId: string, attendeeId: string): Observable<string> {
      return this.http.get(`${this.url}ticket-id/${eventId}/${attendeeId}`,{responseType:"text"});
    }
  

    cancelTicket(ticketId: string): Observable<any> { 
      return this.http.put(`${this.url}cancelticket/${ticketId}`,{}); 
    }

    public addTicket(ticket:TicketRequest):Observable<any>{
      return this.http.post<any>(`${this.url}addticket`, ticket,{responseType:'json'});
    }
    
public processPayment(ticket: TicketRequest, paymentMethod: string): Observable<TicketResponse> {
    return this.http.post<TicketResponse>(`${this.url}processpayment/${paymentMethod}`, ticket);
  }

  public shareTicket(ticketid:string): Observable<TicketShare> {
      return this.http.get<TicketShare>(`${this.url}shareticket/${ticketid}`,{responseType:'json'});
    }
  
 
    
}
