import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

 url:string="http://localhost:9091/admin";
  constructor(private h: HttpClient) { }

  public getAllUser():Observable<any>{
    return this.h.get(this.url+"/getalluser")
  }
  public deleteUser(id:string):Observable<any>{
    return this.h.delete(this.url+"/deleteaccount/"+id);
  }
  public showAllEvents():Observable<any>{
    return this.h.get<any>(this.url +"/getallevents");
  }

  public deleteEvent(id:string):Observable<any>{
    return this.h.delete(this.url+"/deleteeventbyid/"+id);
  }

  public deleteTicket(id: string): Observable<any> {
    return this.h.put<any>(`${this.url}/cancelticket/${id}`, {});
  }
  public getAllTickets(id: string): Observable<any> {
    return this.h.get<any>(`${this.url}/showalleventtickets/${id}`);
  }
  
  

}
