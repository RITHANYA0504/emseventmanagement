import { Injectable } from '@angular/core';
import { Feedbackrequest } from '../model/feedbackrequest';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FeedbackDto } from '../model/feedback-dto';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  url: String = "http://localhost:9091/feedback/";

  constructor(private http: HttpClient) { }


  public addFeedback(feedback: Feedbackrequest): Observable<any> {
    return this.http.post(`${this.url}add`, feedback);
  }

  getFeedbackByEventId(eventId: string): Observable<FeedbackDto[]> {
    return this.http.get<FeedbackDto[]>(`${this.url}getfeedbacks/${eventId}`);
  }
  
  public deleteById(feedbackId:string):Observable<string>{
    return this.http.delete<string>(`${this.url}delete/${feedbackId}`)
  }

  getRatingStatsByEventId(eventId: string): Observable<{ eventId: string, totalRatings: number, averageRating: number }> {
    return this.http.get<{ eventId: string, totalRatings: number, averageRating: number }>(
      `${this.url}rating-stats/${eventId}`
    );
  }


}
