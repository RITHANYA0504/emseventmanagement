import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, of } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

url:string="http://localhost:9091/payments";
  constructor(private h: HttpClient) { }

  public getPayments(id:string):Observable<any>{
    return this.h.get<any>(this.url+"/getallbyattendeeid/"+id).pipe(
          catchError((error: HttpErrorResponse) => {
            return of({ errorMsg: error.error?.errorMsg || 'fetch failed' });
          })
        );
  }

}
