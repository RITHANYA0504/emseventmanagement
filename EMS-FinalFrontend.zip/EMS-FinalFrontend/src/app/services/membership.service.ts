import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, of } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class MembershipService {

  
  url:string="http://localhost:9091/membership";
    constructor(private h: HttpClient) { }
  
    public addMembership(userid:string, method:string):Observable<any>{
      
        return this.h.post(`${this.url}/add/${userid}/${method}`,{responseType:'text'});
      
    }
  
  }
  

