import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent {
  userId:string="";
  
newPasswordValue: string = '';
confirmPasswordValue: string = '';
status: string = '';

  constructor(private r:ActivatedRoute,private ser:UserServiceService,private router:Router){
    this.userId=this.r.snapshot.params['userId'];
  }

  
  updatePassword(): void {
    this.status = '';
    if (this.newPasswordValue !== this.confirmPasswordValue) {
      this.status = "New password and Confirm password do not match.";
      return;
    }
      if (this.newPasswordValue.length < 6) {
      this.status = "New password must be at least 6 characters long.";
      return;
    }
      this.ser.updatePassword(this.userId, this.confirmPasswordValue).subscribe(
      (res) => {
        if (res.message) {
          alert(res.message); // Success message from backend
        } else if (res.errorMsg) {
          this.status = res.errorMsg; // Error message from backend
        } else {
          this.status = "Unexpected response from server.";
        }
      },
      (error) => {
        this.status = "An error occurred while updating the password.";
      }
    );
  }
 
 
  backtoLogin():void{
  this.router.navigate(['/'])
  }

}
