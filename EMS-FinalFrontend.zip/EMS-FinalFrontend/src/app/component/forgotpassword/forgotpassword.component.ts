import { Component } from '@angular/core';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent {
  
  name:string="";
  email:string="";
  number:string="";
  status:string="";
  constructor(private ser :UserServiceService){}

  sendmail():void{
    this.ser.sendEmail(this.name, this.email, this.number).subscribe(
      (log) => {
        if (log.errorMsg != undefined) {
          alert(log.errorMsg);
        }   
        if(log.errorMsg==undefined){
          alert("Susscessfully reset link is sent to your email");
        }   
      }
    );
    
    
  }

}
