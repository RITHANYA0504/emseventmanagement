import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from 'src/app/services/event.service';
import { Event } from 'src/app/model/attendees/event';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit{
  @Input() userId:string;
constructor(
    private route: ActivatedRoute,
    private ser:EventService

  ) {}
ngOnInit(): void {
  // this.userId = this.route.snapshot.paramMap.get('userId') || '';
  // if (this.userId) {
  // }
}
status:string;
event:Event=new Event();

addEvent(): void {
  // DO NOT convert startDateTime and endDateTime to new Date() objects.
  // They are already strings from the ngModel binding, in the format
  // 'YYYY-MM-DDTHH:mm', which is what your backend's LocalDateTime likely expects.
  // this.event.startDateTime = new Date(this.event.startDateTime); // REMOVE THIS LINE
  // this.event.endDateTime = new Date(this.event.endDateTime);     // REMOVE THIS LINE

  // For regDate, if your backend expects a LocalDateTime-like string,
  // generate an ISO string of the *current local time* or format it as 'YYYY-MM-DDTHH:mm'.
  // Using new Date() without toISOString() will still send it as a UTC ISO string by default during JSON.stringify.
  // To send it as localdatetime string:
  const now = new Date();
  // Get year, month, day, hours, minutes locally
  const year = now.getFullYear();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  const hours = now.getHours().toString().padStart(2, '0');
  const minutes = now.getMinutes().toString().padStart(2, '0');
  const seconds = now.getSeconds().toString().padStart(2, '0'); // Add seconds if backend needs it

  this.event.regDate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`; // Or omit seconds if not needed

  this.event.organizerId = this.userId;

//   this.ser.addEvent(this.event).subscribe({
//     next: () => this.status = 'Event added successfully!',
//     error: err => this.status = 'Error adding event: ' + err.message
//   });
// }



}
}