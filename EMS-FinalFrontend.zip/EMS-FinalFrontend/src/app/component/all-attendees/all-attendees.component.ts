import { Component, Input, OnInit } from '@angular/core';
import { AttendeeUserDto } from 'src/app/model/attendees/AttendeeUserDto';
import { UserServiceService } from '../../services/user-service.service';

@Component({
  selector: 'app-all-attendees',
  templateUrl: './all-attendees.component.html',
  styleUrls: ['./all-attendees.component.css']
})
export class AllAttendeesComponent implements OnInit {

  @Input()
  event_id:string;
  attendees:AttendeeUserDto[]=[];

  constructor(private ser: UserServiceService){}

  ngOnInit(): void {
    this.getAllAttendee();
  }

  public getAllAttendee(){
    this.ser.getAllAttendees(this.event_id).subscribe((a)=>this.attendees=a);
  }
  getColor(index: number): string {
    const colors = ['#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8', '#6f42c1', '#fd7e14', '#20c997'];
    return colors[index % colors.length];
  }
  

}



