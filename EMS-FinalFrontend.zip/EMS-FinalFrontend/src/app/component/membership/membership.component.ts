
//import { Component, EventEmitter, Input, Output, OnInit, HostListener } from '@angular/core'; // Import OnInit
import { Component, EventEmitter, Input, Output, OnInit, HostListener } from '@angular/core'; // Import OnInit
import { AttendeeUserDto } from 'src/app/model/attendees/AttendeeUserDto';
import { MembershipService } from 'src/app/services/membership.service';
import { UserServiceService } from 'src/app/services/user-service.service';

  

@Component({
  selector: 'app-membership',
  templateUrl: './membership.component.html',
  styleUrls: ['./membership.component.css']
})
export class MembershipComponent implements OnInit{
  
    isScrolled = false;
    selectedMethod: string | null = null;
    dropdownOpen = false;
    cardNumber: string = '';
    cvv: string = '';
    expiry: string = '2025-05'; // default value
    expiryInvalid: boolean = false;
    cardNumberInvalid: boolean = false;
    cvvInvalid: boolean = false;
    user:AttendeeUserDto;
    
    @Input()
    userId: string;
   
  
    showPayment = false;

  
    @Output()
     close = new EventEmitter<void>();

    



    closeModal() {
      this.close.emit();
    }
  
    constructor(private userServ: UserServiceService, private memberServ: MembershipService) { }
  
    // public getEventById(): void {
    //   this.eventServ.getEventById(this.eventId).subscribe((e) => this.event = e);
    // }
  
    // public addTicket(): void {
    //   this.ticketServ.addTicket(this.ticketReq).subscribe((t) => this.ticket = t);
    // }
    public addMembership(): void {
      this.userServ.addMembership(this.userId).subscribe();
      
    }
  
    public membershipPayment(): void {
      this.memberServ.addMembership(this.userId, this.selectedMethod).subscribe();
    }
    


    public processPayment():void{
      this.membershipPayment();
      this.addMembership();
      this.closeModal();
    }
  
    validateCardForm() {
      this.validateCardNumber();
      this.validateExpiry();
      this.validateCVV();
  
      // Mark fields as touched to trigger validation messages
      const fields = document.querySelectorAll('input[name="cardNumber"], input[name="expiry"], input[name="cvv"]');
      fields.forEach((field: any) => field.dispatchEvent(new Event('blur')));
    }
  
    validateCVV() {
      const isValid = /^\d{3,4}$/.test(this.cvv);
      this.cvvInvalid = !isValid;
    }
  
    validateCardNumber() {
      const num = this.cardNumber.replace(/\s+/g, ''); // remove spaces
      let sum = 0;
      let shouldDouble = false;
  
      for (let i = num.length - 1; i >= 0; i--) {
        let digit = parseInt(num.charAt(i), 10);
  
        if (shouldDouble) {
          digit *= 2;
          if (digit > 9) digit -= 9;
        }
  
        sum += digit;
        shouldDouble = !shouldDouble;
      }
  
      this.cardNumberInvalid = sum % 10 !== 0;
    }
  
    validateExpiry() {
      if (!this.expiry) {
        this.expiryInvalid = false;
        return;
      }
  
      const [year, month] = this.expiry.split('-').map(Number);
      const today = new Date();
      const currentYear = today.getFullYear();
      const currentMonth = today.getMonth() + 1; // getMonth() is 0-based
  
      this.expiryInvalid = year < currentYear || (year === currentYear && month < currentMonth);
    }
  
    selectMethod(method: string) {
      this.selectedMethod = method;
    }
  
    upiOptions = [
      { name: 'GPay', icon: 'assets/images/gpay.png' },
      { name: 'PhonePe', icon: 'assets/images/phonepe.png' },
      { name: 'Paytm', icon: 'assets/images/paytm.png' },
      { name: 'Amazon Pay', icon: 'assets/images/amazonpay.png' }
    ];
  
    bankOptions = [
      { name: 'SBI Bank', icon: 'assets/images/sbi.png' },
      { name: 'Indian Bank', icon: 'assets/images/indian bank.png' },
      { name: 'Bank of India', icon: 'assets/images/Bank of India.jpg' },
      { name: 'ICICI Bank', icon: 'assets/images/icici.png' },
      { name: 'HDFC Bank', icon: 'assets/images/hdfc.png' },
      { name: 'Axis Bank', icon: 'assets/images/axis.png' }
    ];
  
    selectedOption = this.upiOptions[0];
    netBankingOption = this.bankOptions[0];
  
    toggleDropdown() {
      this.dropdownOpen = !this.dropdownOpen;
    }
  
    closeDropdown() {
      this.dropdownOpen = false;
    }
  
    selectOption(option: any) {
      this.selectedOption = option;
      this.dropdownOpen = false;
    }
  
    bankingOption(option: any) {
      this.netBankingOption = option;
      this.dropdownOpen = false;
    }
  
    ngOnInit(): void {
    }
  }


