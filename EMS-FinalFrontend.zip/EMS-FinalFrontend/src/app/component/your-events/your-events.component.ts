import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import flatpickr from 'flatpickr';
import { SharedService } from 'src/app/services/shared/shared.service';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-your-events',
  templateUrl: './your-events.component.html',
  styleUrls: ['./your-events.component.css']
})
export class YourEventsComponent implements AfterViewInit,OnInit{

  userId:string;
  choice: string = 'attending';
  selectedDate: Date = new Date();
  preferenceList:string[]=[];
  isEventEmpty: boolean;
  unsaveClicked:string;
  constructor(private userServ: UserServiceService,private route:ActivatedRoute,private sharedService: SharedService) {
  }
  ngOnInit(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      console.log(id)
      this.userId = id;
      

    });
    // this.userId = this.route.snapshot.paramMap.get('userId') || '';

  }

  public f1($event): void {
    this.isEventEmpty = $event;
    
  }
  public unsaveClickedPar($id):void{
    this.unsaveClicked=$id;
    console.log(this.unsaveClicked);
    this.removePreference(this.userId,this.unsaveClicked);
    
  }
  attendChange() {
    this.choice = 'attending';
  }

  hostChange() {
    this.choice = 'hosting';
  }

  savedChange() {
    this.choice = 'saved';
  }

  pastChange() {
    this.choice='past';
  }

  ngAfterViewInit(): void {

    flatpickr("#calendar-only", {
      inline: true,
      defaultDate: this.selectedDate,
      prevArrow: '<i class="bi bi-chevron-left"></i>',
      nextArrow: '<i class="bi bi-chevron-right"></i>',
      onChange: (selectedDates: Date[]) => {
        if (selectedDates.length > 0) {
          this.selectedDate = selectedDates[0];
          console.log(this.selectedDate);
        }
      }

    });
  }

  isToday(): boolean {
    const selected = new Date(this.selectedDate);
    const current = new Date();

    return selected.getFullYear() === current.getFullYear() &&
      selected.getMonth() === current.getMonth() &&
      selected.getDate() === current.getDate();
  }


  public getPreference(userId: string): void {
    this.userServ.getPreference(this.userId).subscribe((p) => this.preferenceList = p);
  }

  public removePreference(userId:string, eventId:string){
    this.userServ.removePreference(userId,eventId).subscribe((p)=> console.log(p));  
    this.choice='';
    setTimeout(() => this.choice ='saved',1);
    this.getPreference(this.userId);
  }
}
