// src/app/homepage/homepage.component.ts
import { Component, OnInit, AfterViewInit } from '@angular/core';
import flatpickr from 'flatpickr';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, distinctUntilChanged, map, Observable, of } from 'rxjs';
// import { switchMap, tap } from 'rxjs/operators'; // Import operators


import { EventService } from 'src/app/services/event.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { SharedService } from 'src/app/services/shared/shared.service';
import { Eventdto } from 'src/app/model/eventdto';
import { User } from 'src/app/model/attendees/User';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit, AfterViewInit {

  events: Eventdto[] = [];
  currentFilteredEvents: Eventdto[] = [];
  displayedEvents: Eventdto[] = [];

  selectedDate: Date = new Date();
  nextEvent: Eventdto | undefined;
  showSuggestedEvents: boolean = true;
  calendarClicked: boolean = false;
  today: Date = new Date();
  userId: string;
  user: User;

  selectedFilterType: string | null = null;
  filterInputValue: any = null;

  filterNameInput: string = '';

  // For reactive filtering with debounce
  filterNameControl = new FormControl();

  selectedSortOption: string | null = null;


  uniqueDates: Date[] = [];
  currentPageIndex: number = 0;
  datesPerPage: number = 4;
  totalPages: number = 0;

  constructor(
    private userServ: UserServiceService,
    private eventService: EventService,
    private router: Router,
    private r: ActivatedRoute,
    private sharedService: SharedService
  ) { }

  ngOnInit(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      this.userId = id;
      if (this.userId) {
        this.userServ.getUser(this.userId).subscribe((us) => {
          this.user = us;
        });
      }
    });

    this.loadAllEvents();

    this.filterNameControl.valueChanges.pipe(
      debounceTime(300), 
      distinctUntilChanged(), 
      map(inputValue => {
        this.filterNameInput = inputValue; 
        this.applyFrontendFilter(); 
      })
    ).subscribe();
  }
  


  

  ngAfterViewInit(): void {
    flatpickr('#calendar', {
      inline: true,
      defaultDate: this.selectedDate,
      prevArrow: '<i class="bi bi-chevron-left"></i>',
      nextArrow: '<i class="bi bi-chevron-right"></i>',
      onChange: (selectedDates: Date[]) => {
        if (selectedDates.length > 0) {
          this.calendarClicked = true;
          this.selectedDate = selectedDates[0];
          this.filterEventsByDate(this.selectedDate);

          const newIndex = this.uniqueDates.findIndex(d => d.toDateString() === this.selectedDate.toDateString());
          if (newIndex !== -1) {
            this.currentPageIndex = Math.floor(newIndex / this.datesPerPage);
          }
        }
      }
    });
  }

  loadAllEvents() {
    this.eventService.getAllEvents().subscribe((data) => {
      this.events = data;
      this.currentFilteredEvents = [...this.events];
      this.processEventsForPagination();
      this.setNextEvent();
    },
    (error) => {
      console.error('Error loading all events:', error);
      this.events = [];
      this.currentFilteredEvents = [];
      this.processEventsForPagination();
    });
  }


  applyFrontendFilter(): void {
    if (!this.filterNameInput) {
      this.currentFilteredEvents = [...this.events];
    } else {
      const filterValue = this.filterNameInput.toLowerCase();
      this.currentFilteredEvents = this.events.filter(event =>
        event.name.toLowerCase().includes(filterValue)
      );
    }
    this.processEventsForPagination(); 
  }

  selectFilterType(type: string): void {
    this.selectedFilterType = type;
    this.filterInputValue = null;
  }

  applyFilter(): void {
    if (!this.selectedFilterType || this.filterInputValue === null || this.filterInputValue === '') {
      this.currentFilteredEvents = [...this.events];
      this.processEventsForPagination();
      return;

    }

  

    let filterObservable: Observable<Eventdto[]>;


    switch (this.selectedFilterType) {
      
      case 'category':
        filterObservable = this.eventService.getEventsByCategory(this.filterInputValue);
        break;
      case 'amount':
        filterObservable = this.eventService.getEventsByAmount(Number(this.filterInputValue));
        break;
      case 'location':
        filterObservable = this.eventService.getEventsByLocation(this.filterInputValue);
        break;
      default:
        filterObservable = of([...this.events]);
        break;
    }

    filterObservable.subscribe(events => {
      this.currentFilteredEvents = events;
      this.processEventsForPagination();
    }, error => {
      console.error('Error applying filter:', error);
      this.currentFilteredEvents = [];
      this.processEventsForPagination();
    });
  }



  resetfilter(): void {
    this.selectedFilterType = null;
    this.filterInputValue = null;
    this.filterNameInput = ''; 
    this.filterNameControl.setValue('');
    this.selectedSortOption = null;
    this.calendarClicked = false;
    this.selectedDate = new Date();
    this.loadAllEvents();
  }


  processEventsForPagination(): void {
    const sortedEvents = [...this.currentFilteredEvents].sort((a, b) => {
      const dateA = new Date(a.startDateTime).getTime();
      const dateB = new Date(b.startDateTime).getTime();
      return dateA - dateB;
    });

    const uniqueDatesSet = new Set<string>();
    this.uniqueDates = [];

    sortedEvents.forEach(event => {
      const eventDate = new Date(event.startDateTime);
      const dateKey = eventDate.toDateString();
      if (!uniqueDatesSet.has(dateKey)) {
        uniqueDatesSet.add(dateKey);
        this.uniqueDates.push(eventDate);
      }
    });

    this.uniqueDates.sort((a, b) => a.getTime() - b.getTime());

    this.totalPages = Math.ceil(this.uniqueDates.length / this.datesPerPage);

    // Determine the starting date for pagination
    let initialDate: Date | undefined;
    const todayKey = this.today.toDateString();
    const todayIndex = this.uniqueDates.findIndex(d => d.toDateString() === todayKey);

    if (todayIndex !== -1) {
      initialDate = this.uniqueDates[todayIndex];
      this.currentPageIndex = Math.floor(todayIndex / this.datesPerPage);
    } else if (this.uniqueDates.length > 0 && this.nextEvent) {
      const nextEventDate = new Date(this.nextEvent.startDateTime);
      const nextEventIndex = this.uniqueDates.findIndex(d => d.toDateString() === nextEventDate.toDateString());
      if (nextEventIndex !== -1) {
        initialDate = this.uniqueDates[nextEventIndex];
        this.currentPageIndex = Math.floor(nextEventIndex / this.datesPerPage);
      } else {
        initialDate = this.uniqueDates[0];
        this.currentPageIndex = 0;
      }
    } else if (this.uniqueDates.length > 0) {
      initialDate = this.uniqueDates[0];
      this.currentPageIndex = 0;
    } else {
      initialDate = new Date();
      this.currentPageIndex = 0;
    }

    this.selectedDate = initialDate || new Date();
    this.filterEventsByDate(this.selectedDate);
  }

  filterEventsByDate(date: Date): void {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    this.displayedEvents = this.currentFilteredEvents.filter(event => {
      const eventDate = new Date(event.startDateTime);
      return eventDate >= startOfDay && eventDate <= endOfDay;
    }).sort((a, b) => new Date(a.startDateTime).getTime() - new Date(b.startDateTime).getTime());
  }

  specificEvent(eventid: string): void {
    this.router.navigate(['/event', eventid]);
  }

  setNextEvent(): void {
    const now = new Date();
    const upcomingEvents = this.events
      .filter(event => new Date(event.startDateTime) >= now)
      .sort((a, b) => new Date(a.startDateTime).getTime() - new Date(b.startDateTime).getTime());

    this.nextEvent = upcomingEvents.length > 0 ? upcomingEvents[0] : undefined;
  }

  toggleSuggestedEvents(): void {
    this.showSuggestedEvents = !this.showSuggestedEvents;
  }

  saveEvent(eventId: string): void {
    if (this.userId) {
      this.userServ.addPreference(this.userId, eventId).subscribe(
        response => alert ('Event saved successfully!'),
        error => console.error('Error saving event:', error)
      );
    } else {
      console.warn('Cannot save event: userId is not available.');
    }
  }


  get paginationDates(): Date[] {
    const startIndex = this.currentPageIndex * this.datesPerPage;
    const endIndex = startIndex + this.datesPerPage;
    return this.uniqueDates.slice(startIndex, endIndex);
  }

  goToPreviousPage(): void {
    if (this.currentPageIndex > 0) {
      this.currentPageIndex--;
      this.selectedDate = this.paginationDates[0] || this.selectedDate;
      this.filterEventsByDate(this.selectedDate);
      this.calendarClicked = false;
    }
  }

  goToNextPage(): void {
    if (this.currentPageIndex < this.totalPages - 1) {
      this.currentPageIndex++;
      this.selectedDate = this.paginationDates[0] || this.selectedDate;
      this.filterEventsByDate(this.selectedDate);
      this.calendarClicked = false;
    }
  }

  selectPageByDate(date: Date): void {
    this.selectedDate = date;
    this.calendarClicked = true;
    this.filterEventsByDate(this.selectedDate);
  }

  shiftEvent() {
    this.router.navigate(['/your-events']);
  }

}