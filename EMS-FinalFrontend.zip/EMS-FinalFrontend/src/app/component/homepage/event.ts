export interface Event {
    id: number;
  date: Date;
  title: string;
  group: string;
  location: string;
  image: string;
  isAttending: boolean;
  attendeesDisplay: string;
  attendeesCount: number;
}
