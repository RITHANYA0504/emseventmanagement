import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/app/services/notification.service';
import { Notification } from 'src/app/model/attendees/Notification';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SharedService } from 'src/app/services/shared/shared.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  notifications: Notification[] = [];
  userId: string;

  constructor(private notificationService: NotificationService,private router: Router,private route:ActivatedRoute,private sharedService:SharedService) {}

  ngOnInit(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      
      this.userId = id;


    });
    this.loadNotifications();
  }

  loadNotifications(): void {
    this.notificationService.getNotificationById(this.userId).subscribe({
      next: (data: Notification[]) => {
        this.notifications = data.sort((a,b)=>{
          return (a.readorunread === b.readorunread)?0:a.readorunread?1:-1;
        });
      },
      error: (err) => console.error('Error loading notifications:', err)
    });
    console.log(this.notifications)
  }
 
  deleteNotification(notification: Notification): void {
    this.notificationService.notificationDelete(notification.notificationId).subscribe(
      response => {
        console.log('Notification deleted successfully:', response);
        this.notifications = this.notifications.filter(n => n.notificationId !== notification.notificationId);
      },
      error => {
        console.error('Error deleting notification:', error);
      }
    );
  }
 
 
  markAsRead(notification: Notification): void {
    console.log(notification);
    if (!notification.readorunread) {
      this.notificationService.markAsRead(notification.notificationId).subscribe({
        next: () => {
          notification.readorunread = true;
        },
        error: (err) => console.error('Error marking as read:', err)
      });
    }
  }
 
  Back():void
  {
   
    this.router.navigate(['/homepage']);
   
 
 
  }
}