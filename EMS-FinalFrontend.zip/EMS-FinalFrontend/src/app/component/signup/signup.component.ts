import { Component } from '@angular/core';
import { User } from 'src/app/model/attendees/User';

import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user: User = new User();
  confirmPasswordValue: string = '';
  status: string = '';
  signupSuccess: boolean = false;
 
  constructor(private ser: UserServiceService) {}
 
  public signup(): void {
    if (this.user.password !== this.confirmPasswordValue) {
      this.status = 'Password and confirm password are not same!!';
      return;
    }
 
    if (
      !this.validateEmail(this.user.email) ||
      !this.validatePassword(this.user.password) ||
      !this.validatePhone(this.user.contactNumber)
    ) {
      this.status = 'Please correct the highlighted errors before submitting.';
      return;
    }
 
    this.ser.signUp(this.user).subscribe((log) => {
      if (log.errorMsg !== undefined) {
        this.status = log.errorMsg;
        this.signupSuccess = false;
      } else {
        this.signupSuccess = true;
        this.status = 'Signed up successfully! You can now log in.';
      }
    });
  }
 
  validateEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.(com)$/.test(email);
  }
 
  validatePassword(password: string): boolean {
    return /^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{6,}$/.test(password);
  }
 
  validatePhone(phone: string): boolean {
    return /^\d{10}$/.test(phone);
  }
}
