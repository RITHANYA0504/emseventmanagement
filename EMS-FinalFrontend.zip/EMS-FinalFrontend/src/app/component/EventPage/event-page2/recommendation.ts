export interface Recommendation {

    id:string;
    date: string;
      title: string ;
      description: string ;
      location: string ;
      hostInitials: string [];
      attendeeCount: number;
}
