import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventPage2Component } from './event-page2.component';

describe('EventPage2Component', () => {
  let component: EventPage2Component;
  let fixture: ComponentFixture<EventPage2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventPage2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventPage2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
