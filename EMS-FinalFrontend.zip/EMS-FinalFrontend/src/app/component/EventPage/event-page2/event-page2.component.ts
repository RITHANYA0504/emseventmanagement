import { AfterViewInit, Component, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { Recommendation } from './recommendation';
import { EventService } from '../../../services/event.service';
import { Eventdto } from '../../../model/eventdto';
import { Feedbackrequest } from '../../../model/feedbackrequest';
import { TicketService } from '../../../services/ticket.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FeedbackService } from '../../../services/feedback.service';
import { SharedService } from 'src/app/services/shared/shared.service';
import { UserServiceService } from 'src/app/services/user-service.service';


@Component({
  selector: 'app-event-page2',
  templateUrl: './event-page2.component.html',
  styleUrls: ['./event-page2.component.css']
})
export class EventPage2Component implements OnInit {

  eventData!: Eventdto;
  eventname: string = '';
  orgname: string = '';
  image: string = '';
  price: string = '';
  isScrolled = false;
  detailsList: string[] = [];
  displayDate = '';
  city = '';
  location = '';
  startTime = '';
  endTime = '';
  eventstartday = '';
  eventendday = '';
  startDate = '';
  endDate = '';
  organizerid = '';
  feedbackSubmitted: boolean = false;
  showEventNotFound: boolean = false;
  showShare: boolean = false;
  today:string = new Date().toISOString();

  eventid: string = ''
  attendeeid: string = ''






  bookingStatus: string | undefined;
  isExpired: boolean = false;
  ticketid: string = ''

  averageRating: number = 0;
  totalRatings: number = 0;

  showPayment:boolean = false;
  showCancel:boolean = false
  showfeedback:boolean=false;


  openPayment() {
    this.showPayment = true;
  }

  closePayment() {
    this.showPayment = false;
    window.location.reload();
  }

  opencancel() {
    this.showCancel = true;
  }

  closecancel() {
    this.showCancel = false;

  }

  openShare() {
    this.showShare = true;
  }

  closeShare() {
    this.showShare = false;

  }


  openfeedback(){
    this.showfeedback =true;
  }
 
  closefeedback(){
    this.showfeedback=false;
  }




  feedbackText: string = '';
  showFeedbackControls: boolean = false;
  currentRating: number = 0;
  hoverRating: number = 0;


  recentFeedbacks: any[] = [];



  get averageRatingStars(): number {

    return this.averageRating;
  }
  constructor(private userService:UserServiceService,private eventService: EventService, private ticketService: TicketService, private feedbackService: FeedbackService, private router: ActivatedRoute, private route: Router, private sharedService: SharedService) {
    // this.eventid = this.router.snapshot.params['eventid']
    // private sharedService: SharedService,
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.isScrolled = window.scrollY > 20;
  }
  recommendations: Recommendation[] = [];



  // Feedback methods
  onStarHover(rating: number): void {
    this.hoverRating = rating;
  }

  onStarLeave(): void {
    this.hoverRating = 0; // Reset hover rating when mouse leaves stars
  }

  onStarClick(rating: number): void {
    this.currentRating = rating; // Set the actual rating
    this.hoverRating = 0; // Clear hover state
    console.log(`User rated ${this.currentRating} stars. Score: ${this.calculateScore(this.currentRating)}/100`);
  }

  calculateScore(rating: number): number {
    return rating * 20;
  }

  // New getter to check if feedback is valid for submission
  isFeedbackValid(): boolean {
    return this.feedbackText.trim().length > 0 && this.currentRating > 0;
  }

  submitFeedback(): void {
    if (!this.isFeedbackValid()) {
      console.warn('Feedback text and rating are required to submit feedback.');
      return;
    }
    console.log(this.hoverRating);
    const feedback: Feedbackrequest = {

      rating: this.currentRating,
      comments: this.feedbackText,
      eventId: this.eventid,
      attendeeId: this.attendeeid
    };

    this.feedbackService.addFeedback(feedback).subscribe({
      next: (response) => {
        console.log('Feedback submitted:', response);
        this.feedbackText = '';
        this.currentRating = 0;
        this.showFeedbackControls = false;
        this.feedbackSubmitted = true;

        setTimeout(() => {
          this.feedbackSubmitted = false;
        }, 3000);

        this.loadRecentFeedbacks()


      },
      error: (err) => {
        console.error('Error submitting feedback:', err);

      }
    });
  }

  onFeedbackInputBlur(): void {
    setTimeout(() => {
      const feedbackInput = document.querySelector('.feedback-input') as HTMLInputElement;
      if (!feedbackInput || document.activeElement !== feedbackInput) {
        if (this.feedbackText.trim() === '' && this.currentRating === 0) {
          this.showFeedbackControls = false;
        }
      }
    }, 100);
  }


  scrolltotop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }



  loadRecentFeedbacks() {
    this.feedbackService.getFeedbackByEventId(this.eventid).subscribe(data => {
      this.recentFeedbacks = data.sort((a, b) => new Date(b.timeStamp).getTime() - new Date(a.timeStamp).getTime());
    });
    console.log(this.recentFeedbacks)
  }

  
  loadEventDetails(id: string): void {
    console.log(this.eventid)
    this.eventService.getEventById(this.eventid).subscribe(data => {
      this.eventData = data;

      this.showEventNotFound = false;

      this.eventname = this.eventData.name;
      this.orgname = this.eventData.organizername;
      this.organizerid = this.eventData.organizerId;
      this.image = this.eventData.url;
      this.price = this.eventData.price === 0 ? "FREE" : `₹${this.eventData.price}`
      this.location = this.eventData.location;


      // Extract city
      this.city = this.location?.split('·')[1]?.split(',')[0].trim() || '';


      const eventDate = new Date(this.eventData.startDateTime);

      const month = eventDate.toLocaleString('en-US', { month: 'long' });

      const day = eventDate.getDate();

      const year = eventDate.getFullYear();

      this.startDate = `${month}, ${day} ${year}`;

      const eventEDate = new Date(this.eventData.endDateTime);

      const monthe = eventEDate.toLocaleString('en-US', { month: 'long' });

      const daye = eventEDate.getDate();

      const yeare = eventEDate.getFullYear();

      this.endDate = `${monthe}, ${daye} ${yeare}`;



      // Format times
      this.startTime = new Date(this.eventData.startDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      this.endTime = new Date(this.eventData.endDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Format days
      this.eventstartday = new Date(this.eventData.startDateTime).toLocaleDateString('en-US', { weekday: 'long' });
      this.eventendday = new Date(this.eventData.endDateTime).toLocaleDateString('en-US', { weekday: 'long' });

      // Display date
      this.displayDate = this.eventstartday === this.eventendday
        ? `${this.eventstartday}, ${this.startDate}`
        : `${this.eventstartday}, ${this.startDate} ${this.startTime} - ${this.eventendday},${this.endDate} ${this.endTime}`;


      this.eventService.isEventExpired(this.eventData.eventId).subscribe({
        next: (result) => {
          this.isExpired = result;
          console.log(result)
        },
        error: (err) => {
          console.error(err);
        }
      });



      this.detailsList = this.eventData.description
        .split(/\.\s+/)
        .map(item => item.trim())
        .filter(item => item.length > 0)
        .map(item => item.endsWith('.') ? item : item + '.');


      if (this.organizerid) {
        this.eventService.getEventsByOrganizer(this.organizerid).subscribe(events => {
          const filteredEvents = events.filter(e => e.eventId !== this.eventData.eventId && !this.isExpired);


          this.recommendations = filteredEvents.map(Eventdto => ({
            date: new Date(Eventdto.startDateTime).toLocaleString('en-IN', {
              weekday: 'short',
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: 'numeric',
              minute: 'numeric',
              hour12: true,
              timeZoneName: 'short'
            }).toUpperCase(),
            id: Eventdto.eventId,
            title: Eventdto.name,
            description: Eventdto.description,
            location: Eventdto.location,
            hostInitials: Eventdto.organizername ? Eventdto.organizername.split(' ').map(n => n[0]).slice(0, 2) : ['?', '?'],
            attendeeCount: Eventdto.maxCount || 0
          }));
        });


        this.feedbackService.getRatingStatsByEventId(this.eventid).subscribe(stats => {
          this.averageRating = stats.averageRating;
          this.totalRatings = stats.totalRatings;
        });



      }
    });

  }
updateEvent(){
  this.route.navigate([`/updateevent/${this.eventid}`])
}
  


  deleteEvent():void{
    this.eventService.deleteById(this.eventid).subscribe({});
    alert("Event Deletion Successfull");
     this.route.navigate(['/homepage'])
  }

  loadattendees():void{
    this.route.navigate(['/your-events'])
  }

  saveEvent(): void {
    if (this.attendeeid) {
      this.userService.addPreference(this.attendeeid, this.eventid).subscribe(
        response => alert ('Event saved successfully!'),
        error => console.error('Error saving event:', error)
      );
    } else {
      console.warn('Cannot save event: userId is not available.');
    }
  }


  ngOnInit(): void {

    this.sharedService
      .attendeeId$.subscribe(id => {
        this.attendeeid = id;
      });



    // this.sharedService.attendeeId$.subscribe(id => {
    //   console.log(id)
    //   this.attendeeid = id;
    // });

    this.router.paramMap.subscribe(params => {
      this.eventid = params.get('eventid');

      this.eventService.validateEventId(this.eventid).subscribe(result => {
        if (!result) {
          this.route.navigate(['/not-found']);
        }
        this.loadEventDetails(this.eventid);
        this.loadEventDetails(this.eventid);
        this.loadRecentFeedbacks(); 
        

        if (this.attendeeid === this.organizerid) {
          this.eventService.getEventById(this.eventid).subscribe({
            next: (e) => {
              console.log(e.status)
              if (e.status === true) {
                this.bookingStatus = 'CANCELED_EVENT';
              } else {
                
                this.bookingStatus = 'ORGANIZER_VIEW';
              }
            },
            error: (err) => {
              console.error('Error fetching event status for organizer:', err);
              this.bookingStatus = 'Error';
            }
          });
        } else if (this.attendeeid) { 
          this.ticketService.getTicketIdByEventAndAttendee(this.eventid, this.attendeeid).subscribe({
            next: (id) => {
              if (id && id.trim() !== '') {
                this.ticketid = id;
                this.ticketService.getBookingStatus(this.ticketid).subscribe({
                  next: (status) => {
                    this.bookingStatus = status;
                  },
                  error: () => {
                    this.bookingStatus = 'Unavailable';
                  }
                });
              } else {
                this.ticketid = '';
                this.bookingStatus = 'Not Found';
              }
            },
            error: () => {
              this.ticketid = '';
              this.bookingStatus = 'Error';
            }
          });
        } else {
          this.bookingStatus = 'NOT_LOGGED_IN';
        }
      }, error => {
        this.route.navigate(['/not-found']);
      });

      if (this.eventid == '' || this.eventid == null || this.eventid == undefined) {
        this.route.navigate(['/not-found']);
      }
    });
  }

  }
 








