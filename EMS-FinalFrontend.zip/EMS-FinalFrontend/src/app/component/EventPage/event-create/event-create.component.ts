import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { EventService } from 'src/app/services/event.service';
import { SharedService } from 'src/app/services/shared/shared.service';

@Component({
  selector: 'app-event-create',
  templateUrl: './event-create.component.html',
  styleUrls: ['./event-create.component.css']
})
export class EventCreateComponent implements OnInit {

  eventForm: FormGroup;
  selectedFile: File | null = null;
  organizerId: string = '';
  status: string = '';
  imagePreview: string | ArrayBuffer | null = null;
  submitted: boolean = false;

  constructor(private fb: FormBuilder, private eventService: EventService, private sharedService: SharedService) {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      category: ['', Validators.required],
      location: ['', Validators.required],
      regDate: [new Date().toISOString()],
      maxCount: ['', [Validators.required, Validators.min(1), Validators.max(10000)]],
      startDateTime: ['', [Validators.required, this.futureDateValidator()]],
      endDateTime: ['', Validators.required],
      priceType: ['', Validators.required],
      price: [{ value: 0, disabled: true }, [Validators.min(0)]],
      organizerId: [''],
      description: ['', [Validators.required, Validators.minLength(100)]]
    }, { validators: this.dateRangeValidator() });
  }

  ngOnInit(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      
      this.organizerId = id;
      this.eventForm.patchValue({ organizerId: this.organizerId });
      
    });


    this.eventForm.get('priceType')?.valueChanges.subscribe(value => {
      const priceControl = this.eventForm.get('price');
      if (value === 'Free') {
        priceControl?.patchValue(0);
        priceControl?.disable();
        priceControl?.clearValidators();
        priceControl?.updateValueAndValidity();
      } else if (value === 'Paid') {
        priceControl?.enable();
        priceControl?.setValidators([Validators.required, Validators.min(0)]);
      }
      priceControl?.updateValueAndValidity();
    });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(this.selectedFile);
    } else {
      this.imagePreview = null;
    }
  }

 


  futureDateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const selectedDate = new Date(control.value);
      const now = new Date();
      if (selectedDate < now) {
        return { 'futureDate': true };
      }
      return null;
    };
  }


  dateRangeValidator(): ValidatorFn {
    return (formGroup: AbstractControl): { [key: string]: any } | null => {
      const startDateTime = formGroup.get('startDateTime')?.value;
      const endDateTime = formGroup.get('endDateTime')?.value;

      if (startDateTime && endDateTime) {
        const start = new Date(startDateTime);
        const end = new Date(endDateTime);

        if (end < start) {
          formGroup.get('endDateTime')?.setErrors({ 'dateMismatch': true });
          return { 'dateMismatch': true };
        }
      }
      return null;
    };
  }

  onSubmit() {
    this.submitted = true;
    if (this.eventForm.valid && this.selectedFile) {
      const eventData = { ...this.eventForm.getRawValue() };
      delete eventData.priceType; 

      this.eventService.addEvent(eventData, this.selectedFile).subscribe({
        next: (response) => {
          this.status = 'Event added successfully!';
          
          this.eventForm.reset();
          this.selectedFile = null;
          this.imagePreview = null;
          this.submitted = false;

          
          this.eventForm.get('priceType')?.patchValue('');
          this.eventForm.get('price')?.patchValue(0);
          this.eventForm.get('price')?.disable();
          this.eventForm.get('price')?.clearValidators(); 
          this.eventForm.get('price')?.updateValueAndValidity(); 
          window.location.reload();
        },
        error: (err) => {
          this.status = 'Error creating event: ' + (err.error?.message || err.message);
          console.error('Error creating event:', err);
        }
      });
    } else {
      this.status = 'Error: Please fill in all required fields and upload an image.';

      this.eventForm.markAllAsTouched();
    }
  }
}