import { Component, EventEmitter, Input, Output, OnInit, HostListener } from '@angular/core'; // Import OnInit
import { Eventdto } from '../../../model/eventdto';
import { TicketResponse } from '../../../model/ticket-response';
import { TicketRequest } from '../../../model/ticket-request';
import { Ticket } from '../../../model/ticket';
import { EventService } from '../../../services/event.service';
import { TicketService } from '../../../services/ticket.service';

@Component({
  selector: 'app-payment-main',
  templateUrl: './payment-main.component.html',
  styleUrls: ['./payment-main.component.css']
})
export class PaymentMainComponent implements OnInit {


  isScrolled = false;

  selectedMethod: string | null = null;
  dropdownOpen = false;
  cardNumber: string = '';
  cvv: string = '';
  expiry: string = '2025-05'; // default value
  expiryInvalid: boolean = false;
  cardNumberInvalid: boolean = false;
  cvvInvalid: boolean = false;

  event: Eventdto;
  @Input()
  userId: string;
  @Input()
  eventId: string;

  showPayment = false;
  ticketRes: TicketResponse;
  ticket: Ticket;
  ticketReq: TicketRequest; // Declare it, but don't initialize here

  @Output() close = new EventEmitter<void>();

  closeModal() {
    this.close.emit();
  }

  constructor(private eventServ: EventService, private ticketServ: TicketService) { }

  public getEventById(): void {
    this.eventServ.getEventById(this.eventId).subscribe((e) => this.event = e);
  }

  public addTicket(): void {
    this.ticketServ.addTicket(this.ticketReq).subscribe((t) => this.ticket = t);
  }

  public processPayment(): void {
    this.ticketServ.processPayment(this.ticket, this.selectedMethod).subscribe({
      next: (t) => {
        this.ticketRes = t;
        this.closeModal();
      },
      error: (err) => {
        console.error('Payment failed', err);
        // Optionally show an error message to the user
      }
    });
  }

  validateCardForm() {
    this.validateCardNumber();
    this.validateExpiry();
    this.validateCVV();

    // Mark fields as touched to trigger validation messages
    const fields = document.querySelectorAll('input[name="cardNumber"], input[name="expiry"], input[name="cvv"]');
    fields.forEach((field: any) => field.dispatchEvent(new Event('blur')));
  }

  validateCVV() {
    const isValid = /^\d{3,4}$/.test(this.cvv);
    this.cvvInvalid = !isValid;
  }

  validateCardNumber() {
    const num = this.cardNumber.replace(/\s+/g, ''); // remove spaces
    let sum = 0;
    let shouldDouble = false;

    for (let i = num.length - 1; i >= 0; i--) {
      let digit = parseInt(num.charAt(i), 10);

      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }

      sum += digit;
      shouldDouble = !shouldDouble;
    }

    this.cardNumberInvalid = sum % 10 !== 0;
  }

  validateExpiry() {
    if (!this.expiry) {
      this.expiryInvalid = false;
      return;
    }

    const [year, month] = this.expiry.split('-').map(Number);
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth() + 1; // getMonth() is 0-based

    this.expiryInvalid = year < currentYear || (year === currentYear && month < currentMonth);
  }

  selectMethod(method: string) {
    this.selectedMethod = method;
  }

  upiOptions = [
    { name: 'GPay', icon: 'assets/images/gpay.png' },
    { name: 'PhonePe', icon: 'assets/images/phonepe.png' },
    { name: 'Paytm', icon: 'assets/images/paytm.png' },
    { name: 'Amazon Pay', icon: 'assets/images/amazonpay.png' }
  ];

  bankOptions = [
    { name: 'SBI Bank', icon: 'assets/images/sbi.png' },
    { name: 'Indian Bank', icon: 'assets/images/indian bank.png' },
    { name: 'Bank of India', icon: 'assets/images/Bank of India.jpg' },
    { name: 'ICICI Bank', icon: 'assets/images/icici.png' },
    { name: 'HDFC Bank', icon: 'assets/images/hdfc.png' },
    { name: 'Axis Bank', icon: 'assets/images/axis.png' }
  ];

  selectedOption = this.upiOptions[0];
  netBankingOption = this.bankOptions[0];

  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  closeDropdown() {
    this.dropdownOpen = false;
  }

  selectOption(option: any) {
    this.selectedOption = option;
    this.dropdownOpen = false;
  }

  bankingOption(option: any) {
    this.netBankingOption = option;
    this.dropdownOpen = false;
  }

  ngOnInit(): void {
    // Initialize ticketReq here, where eventId and userId are guaranteed to be available
    this.ticketReq = {
      "eventId": this.eventId,
      "attendeeId": this.userId
    };

    this.getEventById();
    this.addTicket();
  }
}