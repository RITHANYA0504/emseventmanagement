import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Eventdto } from 'src/app/model/eventdto';
import { EventService } from 'src/app/services/event.service';
import { SharedService } from 'src/app/services/shared/shared.service';

@Component({
  selector: 'app-event-update',
  templateUrl: './event-update.component.html',
  styleUrls: ['./event-update.component.css']
})
export class EventUpdateComponent {
  eventForm!: FormGroup;
  selectedFile: File | null = null;
  organizerId: string = '';
  status: string = '';
  imagePreview: string | ArrayBuffer | null = null;
  submitted: boolean = false;
  eventId: string | null = null;
  existingImageUrl: string | null = null;
  showConfirmationModal: boolean = false; 

  constructor(
    private fb: FormBuilder,
    private eventService: EventService,
    private sharedService: SharedService,
    private route: ActivatedRoute,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.initializeForm();
    this.getOrganizerId();
    this.setupPriceTypeChangeListener();
    this.loadEventDetails();
  }

  private initializeForm(): void {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      category: ['', Validators.required],
      location: ['', Validators.required],
      regDate: [new Date().toISOString().slice(0, 16)],
      maxCount: ['', [Validators.required, Validators.min(1), Validators.max(10000)]],
      startDateTime: ['', [Validators.required, this.futureDateValidator()]],
      endDateTime: ['', Validators.required],
      priceType: ['', Validators.required],
      price: [{ value: 0, disabled: true }, [Validators.min(0)]],
      organizerId: [''],
      description: ['', [Validators.required, Validators.minLength(100)]]
    }, { validators: this.dateRangeValidator() });
  }

  private loadEventDetails(): void {
    this.route.paramMap.subscribe(params => {
      this.eventId = params.get('p1');
      if (this.eventId) {
        this.fetchEventData(this.eventId);
      } else {
        this.status = 'Error: No event ID provided for update.';
        this.router.navigate(['/not-found']);
      }
    });
  }

  private fetchEventData(id: string): void {
    this.eventService.getEventById(id).subscribe({
      next: (event: Eventdto) => {
        const startDateTimeFormatted = new Date(event.startDateTime).toISOString().slice(0, 16);
        const endDateTimeFormatted = new Date(event.endDateTime).toISOString().slice(0, 16);

        this.eventForm.patchValue({
          name: event.name,
          category: event.category,
          location: event.location,
          maxCount: event.maxCount,
          startDateTime: startDateTimeFormatted,
          endDateTime: endDateTimeFormatted,
          priceType: event.price > 0 ? 'Paid' : 'Free',
          price: event.price,
          organizerId: event.organizerId,
          description: event.description,
        });

        if (event.price > 0) {
          this.eventForm.get('price')?.enable();
        } else {
          this.eventForm.get('price')?.disable();
        }

        if (event.url) {
          this.existingImageUrl = event.url;
        }
        this.status = '';
      },
      error: (err) => {
        this.status = 'Error loading event data: ' + (err.error?.message || 'Unknown error');
        console.error('Error loading event data:', err);
        this.router.navigate(['/not-found']);
      }
    });
  }

  private getOrganizerId(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      this.organizerId = id;
      this.eventForm.patchValue({ organizerId: this.organizerId });
    });
  }

  private setupPriceTypeChangeListener(): void {
    this.eventForm.get('priceType')?.valueChanges.subscribe(value => {
      const priceControl = this.eventForm.get('price');
      if (value === 'Free') {
        priceControl?.patchValue(0);
        priceControl?.disable();
        priceControl?.clearValidators();
      } else if (value === 'Paid') {
        priceControl?.enable();
        priceControl?.setValidators([Validators.required, Validators.min(0)]);
      }
      priceControl?.updateValueAndValidity();
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result;
      };
      reader.readAsDataURL(this.selectedFile);
    } else {
      this.selectedFile = null;
      this.imagePreview = null;
    }
  }

  futureDateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const selectedDate = new Date(control.value);
      const now = new Date();
      selectedDate.setSeconds(0, 0);
      now.setSeconds(0, 0);
      return selectedDate < now ? { 'futureDate': true } : null;
    };
  }

  dateRangeValidator(): ValidatorFn {
    return (formGroup: AbstractControl): { [key: string]: any } | null => {
      const startDateTime = formGroup.get('startDateTime')?.value;
      const endDateTime = formGroup.get('endDateTime')?.value;

      if (startDateTime && endDateTime) {
        const start = new Date(startDateTime);
        const end = new Date(endDateTime);

        if (end < start) {
          formGroup.get('endDateTime')?.setErrors({ 'dateMismatch': true });
          return { 'dateMismatch': true };
        } else {
          if (formGroup.get('endDateTime')?.hasError('dateMismatch')) {
            const errors = formGroup.get('endDateTime')?.errors;
            if (errors) {
              delete errors['dateMismatch'];
              if (Object.keys(errors).length === 0) {
                formGroup.get('endDateTime')?.setErrors(null);
              } else {
                formGroup.get('endDateTime')?.setErrors(errors);
              }
            }
          }
        }
      }
      return null;
    };
  }

  confirmUpdate(): void {
    this.submitted = true;
    if (this.eventForm.valid) {
      this.showConfirmationModal = true; 
    } else {
      this.status = 'Error: Please correct the form errors before applying changes.';
      this.eventForm.markAllAsTouched();
    }
  }


  cancelUpdate(): void {
    this.showConfirmationModal = false;
  }

  onSubmit(): void {
    this.showConfirmationModal = false; 

    if (!this.eventId) {
      this.status = 'Error: Event ID is missing. Cannot update.';
      return;
    }

    const eventData = { ...this.eventForm.getRawValue() };
    delete eventData.priceType;

    this.eventService.updateEvent(this.eventId, eventData, this.selectedFile || undefined).subscribe({
      next: (response) => {
        this.status = 'Event updated successfully!';
        console.log('Event updated:', response);
        this.selectedFile = null;
        this.imagePreview = null;
        this.submitted = false;
      },
      error: (err) => {
        this.status = 'Error updating event: ' + (err.error?.message || err.message || 'Unknown error');
        console.error('Error updating event:', err);
      }
    });

    this.router.navigate([`/event/${this.eventId}`])
  }
}

