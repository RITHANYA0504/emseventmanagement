import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { TicketService } from 'src/app/services/ticket.service';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent {

  @Input() ticketid: string;
  @Input() show: boolean = false;

  @Output() close = new EventEmitter<void>();

  constructor(private ticketService: TicketService) { }

  closeModal(): void {
    this.close.emit();
  }

  cancelticket(): void {
    if (!this.ticketid) return;

    this.ticketService.cancelTicket(this.ticketid).subscribe({
      next: () => {
        window.location.reload();
        this.closeModal();
        
      }
    });
  }

}
