import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import jsPDF from 'jspdf';
import { catchError, of } from 'rxjs';
import { TicketShare } from 'src/app/model/ticket-share';
import { TicketService } from 'src/app/services/ticket.service';

@Component({
  selector: 'app-share-ticket',
  templateUrl: './share-ticket.component.html',
  styleUrls: ['./share-ticket.component.css']
})
export class ShareTicketComponent implements OnChanges {



  @Input() ticketId: string;
  @Input() show: boolean = false;
  @Output() 
  close = new EventEmitter<void>();
  
    closeModal() {
      this.ticketDetails = null;
      this.close.emit();
    }

  ticketDetails: TicketShare | null = null;

  constructor(private ticketService: TicketService) { }

  ngOnChanges(): void {
    if (this.show && this.ticketId) {
      this.fetchTicketDetails();
    }
  }

  fetchTicketDetails(): void {
    this.ticketService.shareTicket(this.ticketId)
      .pipe(catchError(() => {
        alert('Failed to fetch ticket details.');
        return of(null);
      }))
      .subscribe((data) => {
        this.ticketDetails = data;
      });
  }

  downloadPDF(): void {
    if (!this.ticketDetails) return;

    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Ticket Details', 20, 20);

    const lines = [
      `Ticket ID: ${this.ticketDetails.ticketId}`,
      `Attendee Name: ${this.ticketDetails.attendeeName}`,
      `Event Name: ${this.ticketDetails.eventName}`,
      `Location: ${this.ticketDetails.eventLocation}`,
      `Status: ${this.ticketDetails.status}`,
      `Booking Date: ${this.ticketDetails.bookingDate}`,
      `Start Time: ${this.ticketDetails.startDateTime}`,
      `End Time: ${this.ticketDetails.endDateTime}`,
    ];

    lines.forEach((line, index) => {
      doc.text(line, 20, 40 + index * 10);
    });

    doc.save(`Ticket_${this.ticketDetails.ticketId}.pdf`);
  }

  



}
