import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PaymentResponseDto } from 'src/app/model/attendees/PaymentResponseDto';
import { UseruserDto } from 'src/app/model/attendees/UseruserDto';
import { EventService } from 'src/app/services/event.service';
import { PaymentService } from 'src/app/services/payment.service';
import { SharedService } from 'src/app/services/shared/shared.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { Event } from 'src/app/model/attendees/event';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {
  userId: string = '';
  user: UseruserDto = new UseruserDto();
  isEditMode: boolean = false;
  payments:PaymentResponseDto[]=[];
  msg:string="";
  memship:string;
  constructor(
    private route: ActivatedRoute,
    private ser: UserServiceService,
    private pser:PaymentService,
    private sharedService: SharedService,
    private eser:EventService
  ) {}

  ngOnInit(): void {
    this.sharedService.attendeeId$.subscribe(id => {
      console.log(id)
      this.userId = id;
      console.log(this.userId)

    });
    this.getUser();
    this.getEvents();
  }
  events:Event[]=[];
  getEvents():void{
      this.eser.getEventByUserId(this.userId).subscribe({
        next:(e)=>{
          this.events=e;
          if(this.events===null){
            this.emsg="No events";
          }
   
        }
      })
    }
   

getPayments(): void {
  this.pser.getPayments(this.userId).subscribe({
    next: (u) => {
      if (u.errorMsg != undefined) {
        this.msg = u.errorMsg;
        this.payments = []; // Clear payments on error if desired
      } else {
        this.payments = u; // Correct: Assign to the 'payments' property
        this.msg = ''; // Clear any previous error message
      }
    }
  });
}
  getUser(): void {
    this.ser.checkMemberShip(this.userId).subscribe((st)=>{
      if(st===true){
        this.memship="Have membership";
        this.memstatus=true;
      }
      else{
        this.memship="Not have membership";
        this.memstatus=false;
      }
    });
    this.ser.getUser(this.userId).subscribe({
      next: (u) => {
        this.user = u;
        this.getPayments();
      },
      error: (err) => {
      }
    });
   
  }
  emsg:string='';
  memstatus:boolean;
 isPast(date: string | Date): boolean {
    const inputDate = new Date(date);
    const currentDate = new Date();
    return inputDate < currentDate;
  }

  toggleEdit(): void {
    this.isEditMode = !this.isEditMode;
  }
  saveUser(): void {
    this.ser.updateUser(this.user.userId,this.user).subscribe({
      next: (updatedUser) => {
        if (updatedUser.errorMsg != undefined) {
          alert(updatedUser.errorMsg);
          this.msg = updatedUser.errorMsg;
        }else{
          this.user = updatedUser;
          this.isEditMode = false;
          console.log('User updated successfully:', updatedUser);
        }
      },
      error: (err) => {
        console.error('Error updating user:', err);
      }
    });
  }
 
 
  showPayment = false;
 
 
  openPayment() {
    this.showPayment = true;
  }
 
  closePayment() {
    this.showPayment = false;
    window.location.reload();
  }
 
}
