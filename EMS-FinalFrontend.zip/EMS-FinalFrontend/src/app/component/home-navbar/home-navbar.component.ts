import { Component, Input, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { NotificationService } from 'src/app/services/notification.service';
import { Notification } from 'src/app/model/attendees/Notification';
import { filter } from 'rxjs/operators';
import { SharedService } from 'src/app/services/shared/shared.service';

@Component({
  selector: 'app-home-navbar',
  templateUrl: './home-navbar.component.html',
  styleUrls: ['./home-navbar.component.css']
})
export class HomeNavbarComponent implements OnInit {
search() {
throw new Error('Method not implemented.');
}
  userId:string;
  searchEvent: string = '';
  searchLocation: string = '';
  notificationCount: number = 0;
  notifications: Notification[] = [];

  constructor(private notificationService: NotificationService, private router: Router,private sharedService:SharedService) {}

  ngOnInit(): void {
    this.sharedService
    .attendeeId$.subscribe(id => {
      this.userId = id;
    });

    this.loadNotifications();
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(event => {
      const navEnd = event as NavigationEnd;

      if (navEnd.url === '/home/'+this.userId || navEnd.urlAfterRedirects === '/home/'+this.userId) {
        this.loadNotifications();
      }
    });
    
  }

  loadNotifications(): void {
    this.notificationService.getNotificationById(this.userId).subscribe({
      next: (data: Notification[]) => {
        this.notifications = data.sort((a,b)=>{
          return (a.readorunread === b.readorunread)?0:a.readorunread?1:-1;
        });
        this.notificationCount = data.filter(n => !n.readorunread).length;
      },
      error: (err) => console.error('Error fetching notifications:', err)
    });
  }

  openNotifications(): void {
    this.router.navigate(['/notification']);
  }


  showSignupModal = false;
    openSignupModal() {
      this.showSignupModal = true;
    }
    closeSignupModal() {
      this.showSignupModal = false;
    }

    removeLocalStroge(){
      this.sharedService.clearAttendeeId();
    }
}



