import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';

import { firstValueFrom } from 'rxjs';
import { EventService } from 'src/app/services/event.service';
import { UserServiceService } from 'src/app/services/user-service.service';
import { Event } from 'src/app/model/attendees/event';
import { SharedService } from 'src/app/services/shared/shared.service';
import { Route, Router } from '@angular/router';
@Component({
  selector: 'app-all-events',
  templateUrl: './all-events.component.html',
  styleUrls: ['./all-events.component.css']
})
export class AllEventsComponent implements OnChanges {
  userId: string;
  @Input() filterChoice: string;
  @Input() selectedDate: Date;
  @Output() isEventEmpty: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() unsaveClicked: EventEmitter<string> = new EventEmitter<string>();
  preAddedRes: string;
  organizerid: string;
  events: Event[] = [];
  preferenceList: string[] = [];
  router: any;

  eventId: string;
  tempeventId:string
  bookingstatus: string = ''


  constructor(private eventService: EventService, private userServ: UserServiceService, private sharedService: SharedService, private route: Router) {
  }


  ngOnInit() {
    this.applyFilter();
    this.sharedService.attendeeId$.subscribe(id => {
      this.userId = id;
    });

  }

  ngOnChanges() {
    this.applyFilter();
  }

  unsave(id: string) {
    this.unsaveClicked.emit(id);
    window.location.reload()

  }



  onSave(eventId: string): void {
    firstValueFrom(this.userServ.addPreference(this.userId, eventId));
    window.location.reload()

  };







  public applyFilter(): void {

    if (this.filterChoice === 'attending') {
      this.eventService.getEventByUserId(this.userId).subscribe((p) => {
        const year = this.selectedDate.getFullYear();
        const month = String(this.selectedDate.getMonth() + 1).padStart(2, '0');
        const day = String(this.selectedDate.getDate()).padStart(2, '0');
        const formattedSelectedDate = `${year}-${month}-${day}`;

        this.events = p.filter((event: any) => {
          const eventDate = new Date(event.startDateTime);
          const eventYear = eventDate.getFullYear();
          const eventMonth = String(eventDate.getMonth() + 1).padStart(2, '0');
          const eventDay = String(eventDate.getDate()).padStart(2, '0');
          const formattedEventDate = `${eventYear}-${eventMonth}-${eventDay}`;
          return formattedEventDate === formattedSelectedDate;

        });
        
        this.organizerid = this.events[0].organizerId;
        this.tempeventId = this.events[0].eventId;
        if (this.events.length == 0) {
          this.isEventEmpty.emit(true);
        } else {
          this.isEventEmpty.emit(false);
        }
      });


    } else if (this.filterChoice === 'hosting') {
      this.eventService.getEventsByOrganizer(this.userId).subscribe((p) => {
        const year = this.selectedDate.getFullYear();
        const month = String(this.selectedDate.getMonth() + 1).padStart(2, '0');
        const day = String(this.selectedDate.getDate()).padStart(2, '0');
        const formattedSelectedDate = `${year}-${month}-${day}`;

        this.events = p.filter((event: any) => {
          const eventDate = new Date(event.startDateTime);
          const eventYear = eventDate.getFullYear();
          const eventMonth = String(eventDate.getMonth() + 1).padStart(2, '0');
          const eventDay = String(eventDate.getDate()).padStart(2, '0');
          const formattedEventDate = `${eventYear}-${eventMonth}-${eventDay}`;
          return formattedEventDate === formattedSelectedDate;
        });

      });
    }
    else if (this.filterChoice === 'saved') {
      this.getPreference(this.userId);
      this.eventService.getAllEvents().subscribe((p) => {
        const year = this.selectedDate.getFullYear();
        const month = String(this.selectedDate.getMonth() + 1).padStart(2, '0');
        const day = String(this.selectedDate.getDate()).padStart(2, '0');
        const formattedSelectedDate = `${year}-${month}-${day}`;

        this.events = p.filter((event: any) => {
          const eventDate = new Date(event.startDateTime);
          const eventYear = eventDate.getFullYear();
          const eventMonth = String(eventDate.getMonth() + 1).padStart(2, '0');
          const eventDay = String(eventDate.getDate()).padStart(2, '0');
          const formattedEventDate = `${eventYear}-${eventMonth}-${eventDay}`;

          return this.preferenceList.includes(event.eventId) && formattedEventDate === formattedSelectedDate;
        });
      });
      console.log(this.preferenceList)
    }
    else if (this.filterChoice === 'past') {

      this.eventService.getEventByUserId(this.userId).subscribe((p) => {
        const now = new Date(); // current date and time

        if (p && p.length > 0) {
          this.organizerid = p[0].organizerId;
        }
        


        this.events = p.filter((event: any) => {
          const eventEnd = new Date(event.endDateTime); 
          return eventEnd < now; 
        });
      });


    }
  }


  public addPreference(userId: string, eventId: string, e: Event): void {
    
    this.userServ.addPreference(this.userId, eventId).subscribe((p) => this.preAddedRes = p);
    
  }


  public getPreference(userId: string): void {
    this.userServ.getPreference(userId).subscribe((p) => this.preferenceList = p);
  }

  public changeEventId(id: string): void {
    this.eventId = id;
  }



  viewAttendee(id: string): void {
    if (this.organizerid === this.userId) {
      this.route.navigate(['/attendees/', id]);

      
      
    }
    this.route.navigate(['/event/',id])

    
   
      
  
   
    // this.route.navigate(['/attendees/', id]);
  }
}


