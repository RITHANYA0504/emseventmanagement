import { Component } from '@angular/core';
import { EventCreateComponent } from "../EventPage/event-create/event-create.component";


@Component({
  selector: 'app-signup-navbar',
  templateUrl: './signup-navbar.component.html',
  styleUrls: ['./signup-navbar.component.css']
})
export class SignupNavbarComponent {
      searchEvent:string ='';
      searchLocation:string ='';
      
showSignupModal = false;

openSignupModal() {
  this.showSignupModal = true;
}

closeSignupModal() {
   this.showSignupModal = false;
}


      onsearch(){

      }
}
