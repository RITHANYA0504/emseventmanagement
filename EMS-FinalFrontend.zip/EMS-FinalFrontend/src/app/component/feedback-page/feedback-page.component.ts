import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-feedback-page',
  templateUrl: './feedback-page.component.html',
  styleUrls: ['./feedback-page.component.css']
})
export class FeedbackPageComponent implements OnInit {

  @Input() eventid!: string; 
  @Input() eventname!: string;
  feedbackList: any[] = [];
  @Input() show: boolean = false;

  @Output() close = new EventEmitter<void>();
  @Output() feedbackDeleted = new EventEmitter<string>(); 

  getColor(name: string): string {
    const colors = ['#FF5733', '#33A2FF', '#A933FF', '#33FF57', '#FFC733'];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  }

  constructor(
    private route: ActivatedRoute,
    private feedbackService: FeedbackService
  ) { }

  deleteFeedback(id: string) {
    if (confirm('Are you sure you want to delete this feedback?')) { 
      this.feedbackService.deleteById(id).subscribe({
        next: () => { 
          console.log(`Feedback with ID ${id} deleted successfully.`);
          this.loadFeedback(); 
          this.feedbackDeleted.emit(id); 
        },
        error: (err) => { 
          console.error(`Error deleting feedback with ID ${id}:`, err);
          alert('Failed to delete feedback. Please try again.'); 
        }
      });
    }
  }

  ngOnInit(): void {
    
    if (this.eventid) {
      this.loadFeedback();
    } else {

      this.route.paramMap.subscribe(params => {
        const routeEventId = params.get('eventid'); 
        if (routeEventId) {
          this.eventid = routeEventId;
          this.loadFeedback();
          
        }
      });
    }
  }

  closeModal(): void {
    this.close.emit();
  }

  loadFeedback(): void {
    if (this.eventid) {
      this.feedbackService.getFeedbackByEventId(this.eventid).subscribe(data => {
        console.log(data)
        this.feedbackList = data.sort((a, b) => new Date(b.timeStamp).getTime() - new Date(a.timeStamp).getTime());
      },
      error => {
        console.error('Error loading feedback:', error);
        this.feedbackList = []; 
      });
    } else {
      console.warn('Event ID is not available to load feedback.');
    }
  }
}