import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/model/attendees/User';
import { EventService } from 'src/app/services/event.service';
import { UserServiceService } from 'src/app/services/user-service.service';


@Component({
  selector: 'app-attendees',
  templateUrl: './attendees.component.html',
  styleUrls: ['./attendees.component.css']
})
export class AttendeesComponent {

  attendeeList: User[]=[];
  eventId:string;
  event: Event;

  constructor(private everntService: EventService,private userServ:UserServiceService,private r :ActivatedRoute,private route: Router){
    this.eventId=this.r.snapshot.params['eventId'];
    console.log(this.eventId);
    this.getAtteendeByEvent(this.eventId);
  }

 

  public getAtteendeByEvent(eventId:string):void{
    this.userServ.getAttendeeByEvent(eventId).subscribe((p)=> 
      this.attendeeList=p);
  }


 


}
