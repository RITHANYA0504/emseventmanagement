import { Component } from '@angular/core';

import { Router } from '@angular/router';
import { UseruserDto } from 'src/app/model/attendees/UseruserDto';
import { SharedService } from 'src/app/services/shared/shared.service';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {


  user:UseruserDto=new UseruserDto();
  username:string;
  loginpassword:string;
  msg:string="";

  constructor(private ser: UserServiceService,private r :Router,private sharedService:SharedService){
  }

  shareId() {
    this.sharedService.setAttendeeId(this.user.userId);

  }

  public login(): void {
    this.ser.login(this.username, this.loginpassword).subscribe((log) => {
      
      if (log.errorMsg != undefined) {
        this.msg = log.errorMsg;
      } else {
        this.user = log;
        this.shareId()
        this.r.navigate(['/homepage']);
      }
    });
  }

  public forgotpassword():void{
    this.r.navigate(['/forgot']);
 
  }
  

  
  

}
