export interface Eventdto {

    eventId: string;
    name: string;
    category: string;
    location: string;
    regDate: string;
    url: string;
    description: string;
    maxCount: number;
    startDateTime: string;
    endDateTime: string;
    price: number;
    organizerId: string;
    organizername: string;
    status:boolean

}
