export interface Ticket {
    eventId: string,
    attendeeId: string,
    price: number,
    ticketStatus: string,
    membershipStatus:boolean
    
}
