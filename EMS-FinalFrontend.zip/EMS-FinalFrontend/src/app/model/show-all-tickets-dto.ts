export interface ShowAllTicketsDto {
    ticketId: string;
    ticketBookingDate: string;
    eventId: string;
    eventName: string;
    ticketStatus: string;
    attendeeId: string;
    attendeeName: string;
}
