export class NotificationUserDto{
    private  message:string;
	private sentTimeStamp:Date;
	private event_id:string;
}