export class TicketResponseDto{
    private ticketId:string;
	private bookingDate:string;
	private status:string;
	
	private eventName:string;
	private  price:number;
	
	private attendeeId:string;
	private attendeeName:string;
	
	private transactionId:string;
	private paymentStatus:string;
	private paymentMethod:string;
	private paymentDateTime:string;
}