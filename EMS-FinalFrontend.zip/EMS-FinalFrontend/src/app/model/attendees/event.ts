export class Event {
    eventId: string;
    name: string;
    category: string;
    location: string;
    regDate: string;
    url: string;
    description: string;
    maxCount: number;
    startDateTime: string;
    endDateTime: string;
    price: number;
    organizerId: string;
  }
  