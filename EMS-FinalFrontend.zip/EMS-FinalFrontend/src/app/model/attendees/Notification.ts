export interface Notification {
  eventId: string;
  sent_time_stamp: string;
  message: string;
  membershipStatus: boolean;
  attendee_Id: string;
  userId: string;
  email: string;
  contactNumber: string;
  notificationId: string;
  event_name: string;
  readorunread:boolean;
}

