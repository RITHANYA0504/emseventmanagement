export class FeedbackUserDto{
    public feedbackId:string ;
    public rating:number;
    public comment:string;
    public submittedTimestamp:Date;
    public event_id:string;
}