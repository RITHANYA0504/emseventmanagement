export class UseruserDto{
    
	 userId:string;
	 name:string;
	 email:string;
	 password:string;
	 contactNumber:string;
	 age:number;
	 gender:string;
	
}