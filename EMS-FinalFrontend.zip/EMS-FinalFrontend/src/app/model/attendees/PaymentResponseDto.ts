export class PaymentResponseDto{
    attendeeId: string;
    attendeeName: string;
    eventName: string;
    ticketId: string;
    price: number;
    status: string;
    paymentId: string;
    paymentStatus: string;
    paymentMethod: string;
    paymentDateTime: Date;
}