import { FeedbackUserDto } from "./FeedbackUserDto";
import { NotificationUserDto } from "./NotificationUserDto";
import { TicketResponseDto } from "./TicketResponseDto";

export class AttendeeUserDto{
   
userId: string;
name: string;
email: string;
contactNumber: string;
age: number;
gender: string;
memeberShip: boolean;
expiryDate: Date;
preferences: string[];
tickets: TicketResponseDto[];
feedbacks: FeedbackUserDto[];
notifications: NotificationUserDto[];

}