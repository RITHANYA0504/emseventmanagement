export interface TicketRequest {
    eventId: string,
    attendeeId: string
}
