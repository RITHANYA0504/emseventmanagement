export interface TicketResponse {
    eventId: string,
    attendeeId: string,
    price: number,
    ticketStatus: string,
    membershipStatus:boolean,
    ticketId: string,
    bookingDate: Date,
    
    eventName: string,
  
    attendeeName: string,
    transactionId: string,
    paymentStatus: string,
    paymentMethod: string,
    paymentDateTime: Date
}
