export interface Feedbackrequest {

    rating:number;
		
	comments:string;
		
	eventId:string;
		
	attendeeId:string;
}
