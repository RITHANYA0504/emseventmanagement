export interface TicketShare {
    
        ticketId: string;
        attendeeName: string;
        eventName: string;
        eventLocation: string;
        status: string;
        bookingDate: string;
        startDateTime: string;
        endDateTime: string;
      
      
}
