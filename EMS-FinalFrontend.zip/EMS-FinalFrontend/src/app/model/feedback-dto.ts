export interface FeedbackDto {

    feedbackId: string;

    attendeeName:string;

    rating: number;

    comments: string;

    timeStamp: Date;

    eventId: string;

    attendeeId: string;
}
