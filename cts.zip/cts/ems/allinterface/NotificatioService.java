package com.cts.ems.allinterface;

import java.util.List;

import com.cts.ems.dto.NotificationRequestDTO;
import com.cts.ems.dto.NotificationResponseDTO;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Feedback;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.NotificationException;

public interface NotificatioService {
	
		void sendNotification(Event event, Attendee attendee, String msg);
		void sendTicketConfirmation(Ticket ticket, Payment payment);
		void sendPaymentConfirmation(Payment payment);
		List<NotificationResponseDTO> findAllNotification();
		NotificationResponseDTO getNotificationById(String notificationId) throws NotificationException;
		NotificationResponseDTO addNotification(NotificationRequestDTO requestDTO) throws EventException;
		NotificationResponseDTO updateNotificationById(String notificationId, NotificationRequestDTO updatedRequestDTO) throws EventException;
		String deleteNotificationById(String notificationId);
}


