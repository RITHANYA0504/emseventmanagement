package com.cts.ems.allinterface;
 
import java.util.List;
 
import com.cts.ems.dto.OrganizerUserDto;
import com.cts.ems.dto.PaymentUserDto;
import com.cts.ems.entity.Organizer;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;
 
public interface OrganizerService {
	public OrganizerUserDto getOrganizerById(String orgId) throws OrganizerException;
	public String deleteOrganizerById(String id) throws OrganizerException, EventException;
	public List<PaymentUserDto> getAllPayments(String organizerId ,String eventId) throws OrganizerException;
 
}