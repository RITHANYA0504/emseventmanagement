package com.cts.ems.allinterface;
import com.cts.ems.dto.LoginUserDto;
import com.cts.ems.dto.UseruserDto;
import com.cts.ems.entity.User;
import com.cts.ems.exception.UserException;
 
public interface UserService {
 
	public UseruserDto addUser (UseruserDto user)throws UserException;
	public UseruserDto getUser (String id) throws UserException;
	public User updateUser(String id,UseruserDto userDto) throws UserException;
	public String deleteUser(String userId) throws UserException;
	public User forgotPassword(String userName,String email,String number,String newPassword) throws UserException;
	public User updateName(String id,String name) throws UserException;
	public User updateEmail(String id,String email) throws UserException;
	public User updateContactNumber(String id,String number) throws UserException;
	public User updateAge(String id,int age) throws UserException;
	public User updateGender(String id,String gender) throws UserException;
	public User updatePassword(String id, String Password) throws UserException;
	public UseruserDto login(LoginUserDto login) throws UserException;
 
}
 
 