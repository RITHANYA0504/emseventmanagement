package com.cts.ems.allinterface;
 
import java.util.List;
 
import com.cts.ems.dto.AttendeeUserDto;
import com.cts.ems.exception.AttendeeException;
 
public interface AttendeeService {
	
	
	public  AttendeeUserDto getAttendeeById(String id)  throws AttendeeException;
	public List<AttendeeUserDto> getAllAttendees() throws AttendeeException;
 
 
}