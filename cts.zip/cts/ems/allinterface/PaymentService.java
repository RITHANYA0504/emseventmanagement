package com.cts.ems.allinterface;

import java.util.List;

import com.cts.ems.dto.PaymentResponseDto;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;

public interface PaymentService {

	public Payment processPayment(Payment payment, Ticket tic);
	
	void validatePaymentDetails(Payment payment);

	List<Payment> getAllPayment();
	
	Payment getPaymentById(String paymentId);

	//PaymentResponseDto getPaymentDtoById(String paymentId);
	
	String trackPaymentStatus(String paymentId);
	
	PaymentResponseDto generateReport(String paymentId);
	
	boolean isPaymentSuccessful(String paymentId);
	
	List<PaymentResponseDto> getPaymentsByAttendeeId(String attendeeId);
	
	List<PaymentResponseDto> getPaymentsByEventId(String eventId);
	
	PaymentResponseDto refundPayment(String paymentId);
	
	PaymentResponseDto responseToDto(Payment payment);}
