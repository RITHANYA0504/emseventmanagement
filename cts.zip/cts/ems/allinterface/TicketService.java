package com.cts.ems.allinterface;

 
 
import java.util.List;

import com.cts.ems.dto.*;
 
public interface TicketService {
 
    List<ShowAllTicketsDto> showAllTickets();

    TicketResponseDto bookTicket(TicketRequestDto ticketRequest);

    TicketResponseDto cancelTicket(String ticketId);

    TicketResponseDto getTicketDetails(String ticketId);

    List<TicketEventDto> getAttendedEvents(String attendeeId);// throws TicketException;

    List<TicketResponseDto> getExpiredTicket();

    String getBookingStatus(String ticketId);

    TicketResponseDto getTicketDetailsByEventAndAttendee(String eventId,String attedeeId);

    TicketShareResponseDto shareTicket(String ticketId);

    List<ShowAllTicketsDto> showAllTicketsByEvent(String eventId);

    void autoRefundWaitlist();
    
    List<TicketEventResponseDto> getTicketByAttendeeId(String attendeeId);
 
	

}
 