package com.cts.ems.allinterface;

import java.util.List;

import com.cts.ems.dto.FeedbackRequestDTO;
import com.cts.ems.dto.FeedbackResponseDTO;
import com.cts.ems.entity.Feedback;
import com.cts.ems.exception.EventException;


public interface FeedbackService {
	
	//To add Feedback 
	public FeedbackResponseDTO addFeedback(FeedbackRequestDTO feedbackDTO) throws EventException;
	
	//To show All Feedback
	public List<FeedbackResponseDTO> getAllFeedback();
	
	//To update Comments and Rating By Feedback ID
	public FeedbackResponseDTO updateCommentById(String feedbackId,String comment);
	
	public FeedbackResponseDTO updateRatingById(String feedbackId,int rating);
	
	//To Delete Feedback
	public String deleteFeedbackById(String feedbackId);
	
	public FeedbackResponseDTO getFeedbackById(String feedbackId);
}
