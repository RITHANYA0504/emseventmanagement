package com.cts.ems.allinterface;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.ems.dto.EventEventDto;
import com.cts.ems.dto.EventResponseDto;
import com.cts.ems.dto.EventTicketResponseDto;
import com.cts.ems.entity.Event;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;

public interface EventService {

    

    List<EventEventDto> getEventByCategory(String cat);

    List<EventEventDto> getEventByOrganizerId(String orgId) throws EventException, OrganizerException;

    List<EventEventDto> getEventByAmount(Double amt);

    Event validOrganizer(EventEventDto e) throws UserException, EventException, OrganizerException;

    EventEventDto eventToDto(Event event);

    EventEventDto addEvent(EventEventDto event) throws UserException, EventException, OrganizerException;

    EventEventDto getEventById(String id) throws EventException;

    public List<EventResponseDto> getAllEvent();
    
    List<EventEventDto> listEventToDto(List<Event> list);

    EventEventDto deleteById(String id) throws EventException;
}
