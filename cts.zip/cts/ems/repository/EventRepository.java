package com.cts.ems.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;


import com.cts.ems.entity.Event;

public interface EventRepository extends JpaRepository<Event, String> {

    @Query("SELECT e from Event e WHERE e.category =:cat")
    public List<Event> getEventByCategory(@Param ("cat") String category);
    
    @Query("SELECT e from Event e WHERE e.organizer.userId =:orgId")
    public List<Event> getEventByOrganizerId(@Param("orgId") String orgId);
    
    @Query("SELECT e from Event e WHERE e.price <=:amt")
    public List<Event> getEventByAmount(@Param("amt") Double amt);
 
    @Query("SELECT e FROM Event e JOIN FETCH e.tickets")
    public List<Event> findAllEventsWithTickets();

}
