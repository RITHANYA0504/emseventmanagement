package com.cts.ems.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Ticket;

public interface TicketRepository extends JpaRepository<Ticket,String> {


//	@Query("SELECT COUNT(t) FROM Ticket t WHERE t.event = :event AND t.status = :status")
	long countByEventAndStatus( Event event, String status);

 
//   @Query("SELECT t FROM Ticket t WHERE t.event = :event AND t.status = :status ORDER BY t.bookingDate ASC")
	Optional<Ticket> findFirstByEventAndStatusOrderByBookingDateAsc(Event event, String status);
 
 
    @Query("SELECT t FROM Ticket t WHERE t.event.id = :eventId AND t.attendee.id = :attendeeId")
	Optional<Ticket> findByEventIdAndAttendeeId(String eventId,String attendeeId);

 
   
    Optional<Ticket> findByEventAndAttendee(Event event, Attendee attendee);
//    @Query("SELECT t FROM ticket t WHERE t.attendee = :attendee")
    List<Ticket> findByAttendee (Attendee attendee);
//  @Query("SELECT t FROM ticket t WHERE t.attendee = :attendee")
    List<Ticket> findByEvent (Event event);
//  @Query("SELECT t FROM ticket t WHERE t.status = :status")
    List<Ticket> findByStatus(String status);

}


