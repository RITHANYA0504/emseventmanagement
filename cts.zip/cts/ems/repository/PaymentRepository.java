package com.cts.ems.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.ems.dto.PaymentResponseDto;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;

import jakarta.transaction.Transactional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, String> {

	@Modifying
	@Transactional
	@Query("UPDATE Payment p SET p.paymentStatus = :status WHERE p.id = :id")
	void updatePaymentStatus(@Param("id") String id, @Param("status") String status);

	@Query("select p from Payment p where p.ticket.attendee.userId = :attendeeId")
	List<Payment> getPaymentsByAttendeeId(@Param("attendeeId") String attendeeId);

	@Query("select p from Payment p where p.ticket.event.eventId = :eventId")
	List<Payment> getPaymentsByEventId(@Param("eventId") String eventId);
	
	@Modifying
	@Query("update Payment p set p.ticket =:tic where p.paymentId = :id")
	void saveTicket(@Param("id")String  id ,@Param("tic") Ticket tic);
}
