package com.cts.ems.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.ems.entity.Organizer;

public interface OrganizerRepository extends JpaRepository<Organizer, String> {

    @Modifying
    @Query("DELETE FROM Organizer o WHERE o.user.userId = :id")
    void removeOrganizer(@Param("id") String id);
}

