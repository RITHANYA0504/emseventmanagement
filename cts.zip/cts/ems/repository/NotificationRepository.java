package com.cts.ems.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
 
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Notification;
 
import jakarta.transaction.Transactional;
 
@Repository
public interface NotificationRepository extends JpaRepository<Notification, String> {
	boolean existsByEventAndAttendeeAndMessage(Event event, Attendee attendee, String message);
	@Modifying
	@Transactional
	@Query("UPDATE Notification n SET n.message =:message WHERE n.notificationId=:notificationId")
	public void updateNotificationById(@Param("notificationId") String notificationId,
			@Param("message") String message);
}