package com.cts.ems.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cts.ems.entity.Feedback;
import jakarta.transaction.Transactional;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, String> {
	@Modifying
	@Transactional
	@Query("UPDATE Feedback f SET f.comment = :comment,f.submittedTimestamp = now() WHERE f.feedbackId = :id")
	public void updateCommentById(@Param("id") String id, @Param("comment") String comment);
	@Modifying
	@Transactional
	@Query("UPDATE Feedback f SET f.rating = :rating,f.submittedTimestamp = now() WHERE f.feedbackId = :id")
	public void updateRatingById(@Param("id") String id, @Param("rating") int rating);
}


