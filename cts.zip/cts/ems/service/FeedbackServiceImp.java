package com.cts.ems.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ems.allinterface.FeedbackService;

import com.cts.ems.dto.FeedbackRequestDTO;
import com.cts.ems.dto.FeedbackResponseDTO;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Feedback;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.FeedbackException;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.FeedbackRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class FeedbackServiceImp implements FeedbackService {

	private final FeedbackRepository feedbackRepo;

	private final EventServiceImp eventServ;

	private final AttendeeServiceImp attendeeServ;

	public FeedbackResponseDTO response(Feedback feedback) {
		FeedbackResponseDTO responseFeedback = FeedbackResponseDTO.builder().feedbackId(feedback.getFeedbackId())
				.eventId(feedback.getEvent().getEventId()).attendeeId(feedback.getAttendee().getUserId())
				.comments(feedback.getComment()).rating(feedback.getRating())
				.timeStamp(feedback.getSubmittedTimestamp()).build();
		log.info("Displaying Feedback!");
		return responseFeedback;
	}

	public List<FeedbackResponseDTO> getAllFeedback() {
		List<Feedback> flist = feedbackRepo.findAll();

		List<FeedbackResponseDTO> frlist = new ArrayList<FeedbackResponseDTO>();

		for (Feedback f : flist) {
			FeedbackResponseDTO fr = FeedbackResponseDTO.builder()
					.feedbackId(f.getFeedbackId())
					.attendeeId(f.getAttendee().getUserId())
					.eventId(f.getEvent().getEventId())
					.comments(f.getComment())
					.rating(f.getRating())
					.timeStamp(f.getSubmittedTimestamp())
					.build();
			frlist.add(fr);
		}
		log.info("Viewing all Feedback from Users!");
		return frlist;
	}

	public FeedbackResponseDTO getFeedbackById(String feedbackId) throws FeedbackException {

		if (!feedbackRepo.existsById(feedbackId)) {
			log.error("Error: Cannot Identify the Feedback Id: " + feedbackId);
			throw new FeedbackException("Feedback Id :" + feedbackId + " not found.");
		}

		Feedback feedback = feedbackRepo.findById(feedbackId).get();
		log.info("Viewing Feedback of Feedback Id " + feedbackId);
		FeedbackResponseDTO responseFeedback = response(feedback);
		return responseFeedback;

	}

	public FeedbackResponseDTO addFeedback(FeedbackRequestDTO feedbackDTO)throws FeedbackException, EventException {
	    if (feedbackDTO.getEventId() == null) {
	        throw new FeedbackException("Event ID cannot be empty!");
	    }
	    if (feedbackDTO.getAttendeeId() == null) {
	        throw new FeedbackException("Attendee ID cannot be empty!");
	    }
	    if (feedbackDTO.getFeedbackId() == null) {
	        throw new FeedbackException("Feedback ID cannot be empty!");
	    }
	    if (feedbackDTO.getRating() <=0 || feedbackDTO.getRating() > 5) {
	        throw new FeedbackException("Rating cannot be empty!");
	    }
	    if (feedbackDTO.getComments() == null || feedbackDTO.getComments().isEmpty()) {
	        throw new FeedbackException("Comments cannot be empty!");
	    }
 
	    Event event = eventServ.getEventEntityById(feedbackDTO.getEventId());
	    Attendee attendee = attendeeServ.getAttendeeEntityById(feedbackDTO.getAttendeeId());
 
	    Feedback feedbackSet = Feedback.builder()
	        .event(event)
	        .attendee(attendee)
	        .feedbackId(feedbackDTO.getFeedbackId())
	        .rating(feedbackDTO.getRating())
	        .comment(feedbackDTO.getComments())
	        .submittedTimestamp(LocalDateTime.now())
	        .build();
 
	    Feedback saved = feedbackRepo.save(feedbackSet);
	    log.info("Feedback is added Successfully!");
	    FeedbackResponseDTO responseFeedback = response(saved);
	    return responseFeedback;
	}

	@Transactional
	public FeedbackResponseDTO updateCommentById(String feedbackId, String comment) throws FeedbackException {
		if (!feedbackRepo.existsById(feedbackId)) {
			log.error("Cannot Update Feedback!Because cannot find the Feedback Id : " + feedbackId);
			throw new FeedbackException("Feedback Id " + feedbackId + " is not found");
		}

		Feedback feedback = feedbackRepo.findById(feedbackId).get();

		if (comment.equalsIgnoreCase(feedback.getComment())) {
			log.error("Cannot Update Feedback! Comments Looks Same as Old Comment");
			throw new FeedbackException("comments is same as old in the feedback Id: " + feedbackId);
		}

		feedbackRepo.updateCommentById(feedbackId, comment);
		log.info("Updating the comment of Feedback Id : " + feedbackId);
		Feedback saved = feedbackRepo.findById(feedbackId).get();
		saved.setComment(comment);
		saved.setSubmittedTimestamp(LocalDateTime.now());
		FeedbackResponseDTO responseFeedback = response(saved);

		return responseFeedback;

	}

	public FeedbackResponseDTO updateRatingById(String feedbackId, int rating) throws FeedbackException {
		if (!feedbackRepo.existsById(feedbackId)) {
			log.error("Cannot Update Feedback!Because cannot find the Feedback Id : " + feedbackId);
			throw new FeedbackException("Feedback Id " + feedbackId + " is not found");
		}

		Feedback feedback = feedbackRepo.findById(feedbackId).get();

		if (rating == feedback.getRating()) {
			log.error("Cannot Update Feedback! Rating Looks same as old Rating : ");
			throw new FeedbackException("Rating is same as old in the feedback Id" + feedbackId);
		}

		feedbackRepo.updateRatingById(feedbackId, rating);
		log.info("Updated the Rating! for the Feedback Id: " + feedbackId);
		Feedback saved = feedbackRepo.findById(feedbackId).get();
		saved.setRating(rating);
		saved.setSubmittedTimestamp(LocalDateTime.now());
		FeedbackResponseDTO responseFeedback = response(saved);

		return responseFeedback;

	}

	public String deleteFeedbackById(String feedbackId) throws FeedbackException {
		if (!feedbackRepo.existsById(feedbackId)) {
			log.error("Feedback Id: " + feedbackId + " Not present in DB");
			throw new FeedbackException("Feedback Id " + feedbackId + " is not found .So cannot be deleted.");
		}
		feedbackRepo.deleteById(feedbackId);
		log.info("Deleted Sucessfully the Feedback Id: " + feedbackId);
		return "Deleted Id :" + feedbackId;
	}

}