package com.cts.ems.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ems.allinterface.EventService;
import com.cts.ems.dto.EventEventDto;
import com.cts.ems.dto.EventResponseDto;
import com.cts.ems.dto.TicketEventResponseDto;
import com.cts.ems.dto.TicketResponseDto;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Event.EventBuilder;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.Ticket;
import com.cts.ems.entity.User;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.OrganizerRepository;
import com.cts.ems.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class EventServiceImp implements EventService {

	
	private final EventRepository eventRepo;
	
	private final OrganizerServiceImp orgServ;
	
	private final UserServiceImp userServ;
	
	
	
	
	public Event getEventEntityById(String eventId) throws EventException {
		Optional<Event> e = eventRepo.findById(eventId);

	    if (!e.isPresent()) {
	        throw new EventException("No such event present with id: " + eventId);
	    }
		return eventRepo.findById(eventId).get();
	}
	
	public EventEventDto updateEvent(String eventId, EventEventDto event) throws EventException {
	    Optional<Event> e = eventRepo.findById(eventId);

	    if (!e.isPresent()) {
	        throw new EventException("No such event present with id: " + eventId);
	    }
	    
	    Event eve = e.get();
	    
	    if (event.getName() != null) {
	        eve.setName(event.getName());
	    }
	    if (event.getCategory() != null) {
	        eve.setCategory(event.getCategory());
	    }
	    if (event.getLocation() != null) {
	        eve.setLocation(event.getLocation());
	    }
	    if (event.getRegDate() != null) {
	        eve.setRegDate(event.getRegDate());
	    }
	    if (event.getMaxCount() != null) {
	        eve.setMaxCount(event.getMaxCount());
	    }
	    if (event.getStartDateTime() != null) {
	        eve.setStartDateTime(event.getStartDateTime());
	    }
	    if (event.getEndDateTime() != null) {
	        eve.setEndDateTime(event.getEndDateTime());
	    }
	    if (event.getPrice() != null) {
	        eve.setPrice(event.getPrice());
	    }

	    Event res = eventRepo.save(eve);
	    return eventToDto(res);
	}


	public List<EventEventDto> getEventByCategory(String cat) {
		List<Event> list = eventRepo.getEventByCategory(cat);
		return listEventToDto(list);
	}

	public List<EventEventDto> getEventByOrganizerId(String orgId) throws EventException, OrganizerException {

		if (!orgServ.isOrganizerPresent(orgId)) {
			throw new OrganizerException("No such a Organizer with a ID:" + orgId);
		}
		List<Event> list = eventRepo.getEventByOrganizerId(orgId);

		if (list.isEmpty()) {
			throw new EventException("No event is hosted with a organizer ID:" + orgId);
		}

		return listEventToDto(list);
	}

	public List<EventEventDto> getEventByAmount(Double amt) {
		List<Event> list = eventRepo.getEventByAmount(amt);
		return listEventToDto(list);
	}

	public Event validOrganizer(EventEventDto e) throws UserException, EventException, OrganizerException {

	

		 if (!userServ.userIsPresent(e.getOrganizerId())) {

			throw new EventException("No such a user present with id :" + e.getOrganizerId());

		}
		
		 Organizer resOrg = orgServ.getOrganizerEnityById(e.getOrganizerId()).get();
		

		EventBuilder eve = Event.builder().category(e.getCategory()).endDateTime(e.getEndDateTime()).location(e.getLocation())
				.maxCount(e.getMaxCount()).name(e.getName()).regDate(e.getRegDate()).startDateTime(e.getStartDateTime())
				.price(e.getPrice()).organizer(resOrg);

		Event event = eve.build();

		return event;
	}

	public EventEventDto eventToDto(Event event) {
		return EventEventDto.builder().eventId(event.getEventId()).name(event.getName()).category(event.getCategory())
				.location(event.getLocation()).regDate(event.getRegDate()).maxCount(event.getMaxCount())
				.startDateTime(event.getStartDateTime()).endDateTime(event.getEndDateTime()).price(event.getPrice())
				.organizerId(event.getOrganizer().getUserId()).build();
	}

	public EventEventDto addEvent(EventEventDto event) throws UserException, EventException {
	    
	    if (event.getName() == null || event.getName().isEmpty()) {
	        throw new EventException("Event name cannot be empty!");
	    }
	    if (event.getCategory() == null || event.getCategory().isEmpty()) {
	        throw new EventException("Event category cannot be empty!");
	    }
	    if (event.getLocation() == null || event.getLocation().isEmpty()) {
	        throw new EventException("Event location cannot be empty!");
	    }
	    if (event.getRegDate() == null) {
	        throw new EventException("Registration date cannot be empty!");
	    }
	    if (event.getMaxCount() == null) {
	        throw new EventException("Max count cannot be empty!");
	    }
	    if (event.getStartDateTime() == null) {
	        throw new EventException("Start date and time cannot be empty!");
	    }
	    if (event.getEndDateTime() == null) {
	        throw new EventException("End date and time cannot be empty!");
	    }
	    if (event.getPrice() == null) {
	        throw new EventException("Price cannot be empty!");
	    }
	    if (event.getOrganizerId() == null || event.getOrganizerId().isEmpty()) {
	        throw new EventException("Organizer ID cannot be empty!");
	    }
 
	    Event e = validOrganizer(event);
	    Event res = eventRepo.save(e);
	    return eventToDto(res);
	}
 
 

	public EventEventDto getEventById(String id) throws EventException {
		Optional<Event> e = eventRepo.findById(id);
		if (!e.isPresent()) {
			throw new EventException("No such a event present with id :" + id);
		}
		return eventToDto(e.get());
	}

	public List<EventResponseDto> getAllEvent() {
		List<Event> list = eventRepo.findAll();
		
		return listToEventResponseDto(list);
	}
	
	
	public List<Event> getAllEventEntity() {
		List<Event> list = eventRepo.findAll();
		return list;
	}
	
	public List<EventResponseDto> listToEventResponseDto(List<Event> list){
		List<EventResponseDto> resList = new ArrayList<>();
		for (Event e : list) {
			resList.add(eventToEventResponseDto(e));
		}
		return resList;
	}
	
	
	public EventResponseDto eventToEventResponseDto(Event e) {
		List<TicketEventResponseDto> res = new ArrayList<>();
		
		for(Ticket t : e.getTickets()) {
			res.add(responseToDto(t));
		}
		
		 EventResponseDto response = EventResponseDto.builder().eventId(e.getEventId()).name(e.getName()).category(e.getCategory())
					.location(e.getLocation()).regDate(e.getRegDate()).maxCount(e.getMaxCount())
					.startDateTime(e.getStartDateTime()).endDateTime(e.getEndDateTime()).price(e.getPrice())
					.organizerId(e.getOrganizer().getUserId()).tickets((List<TicketEventResponseDto>) res).build();
		 
		 return response;
	}
	
	
	public TicketEventResponseDto responseToDto(Ticket ticket) {
		TicketEventResponseDto response = TicketEventResponseDto.builder()
    	.ticketId(ticket.getTicketId())
    	.bookingDate(ticket.getBookingDate())
    	.status(ticket.getStatus())
    	.eventName(ticket.getEvent().getName())
    	.price(ticket.getEvent().getPrice())
    	.attendeeName(ticket.getAttendee().getUser().getName())
    	.paymentId(ticket.getPayment().getPaymentId())
    	.paymentStatus(ticket.getPayment().getPaymentStatus())
    	.paymentMethod(ticket.getPayment().getPaymentMethod())
    	.paymentDateTime(ticket.getPayment().getPaymentDate()).build();
    	
    	return response;
    }
	
	
	

	public List<EventEventDto> listEventToDto(List<Event> list) {
		List<EventEventDto> resList = new ArrayList<>();
		for (Event e : list) {
			resList.add(eventToDto(e));
		}
		return resList;
	}

	public EventEventDto deleteById(String id) throws EventException {
		Optional<Event> e = eventRepo.findById(id);

		if (!e.isPresent()) {
			throw new EventException("No such a event present with id :" + id);
		}
		eventRepo.deleteById(id);

		return eventToDto(e.get());
	}
}