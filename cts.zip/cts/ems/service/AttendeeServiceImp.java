package com.cts.ems.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cts.ems.allinterface.AttendeeService;

import com.cts.ems.dto.AttendeeUserDto;

import com.cts.ems.dto.FeedbackUserDto;

import com.cts.ems.dto.NotificationUserDto;

import com.cts.ems.entity.Attendee;

import com.cts.ems.entity.Feedback;

import com.cts.ems.entity.Notification;

import com.cts.ems.exception.AttendeeException;

import com.cts.ems.repository.AttendeeRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service

@Slf4j
@RequiredArgsConstructor
public class AttendeeServiceImp implements AttendeeService {

	
	private final AttendeeRepository attendeeRepo;

	public Attendee addAttendee(Attendee atd) {
		return attendeeRepo.save(atd);
	}

	public Attendee deleteById(String id) {
		if (!attendeeRepo.existsById(id)) {
			log.error("Attendee does not exist for id: {}", id);
			throw new AttendeeException("Attendee Not found");
		}
		Optional<Attendee> atd = attendeeRepo.findById(id);
		attendeeRepo.deleteById(id);
		return atd.get();
	}

	public Attendee getAttendeeEntityById(String id) {
		if (!attendeeRepo.existsById(id)) {
			log.error("Attendee does not exist for id: {}", id);
			throw new AttendeeException("Attendee Not found");
		}
		return attendeeRepo.findById(id).get();
	}

	// --------------------------Attendee-----------------------------------------

	// get Attendee by id
	public AttendeeUserDto getAttendeeById(String id) throws AttendeeException {
		if (!attendeeRepo.existsById(id)) {
			log.error("Attendee does not exist for id: {}", id);
			throw new AttendeeException("Attendee Not found");
		}
		Attendee attendee = attendeeRepo.findById(id).orElse(null);
		if (attendee == null)
			return null;
		return attendeeToAttendeeUserDto(attendee);
	}

	// get all attendee
	public List<AttendeeUserDto> getAllAttendees() throws AttendeeException {
		List<Attendee> attendees = attendeeRepo.findAll();
		List<AttendeeUserDto> attendeeDtos = new ArrayList<>();
		if (attendees.isEmpty()) {
			log.error("Attendee does not exist");
			throw new AttendeeException("Attendee table is empty");
		}
		for (Attendee attendee1 : attendees) {
			AttendeeUserDto attendeeDto = attendeeToAttendeeUserDto(attendee1);
			attendeeDtos.add(attendeeDto);
		}
		return attendeeDtos;
	}
	// if you want to delete the attendee delete User
	// if you want to update the attendee update user
	// Attendee to AttendeeUserDto
	public AttendeeUserDto attendeeToAttendeeUserDto(Attendee attendee) {
		List<Feedback> feedList = attendee.getFeedbacks();
		List<FeedbackUserDto> feedbackDtoList = new ArrayList<>();
		for (Feedback feedback : feedList) {
			FeedbackUserDto feedbackDto = feedbacktoFeedbackUserDto(feedback);
			feedbackDtoList.add(feedbackDto);
		}
		List<Notification> notificationList = attendee.getNotifications();
		List<NotificationUserDto> notificationDtoList = new ArrayList<>();
		for (Notification notification : notificationList) {
			NotificationUserDto notificationDto = notificationToNotificationUserDto(notification);
			notificationDtoList.add(notificationDto);
		}
		AttendeeUserDto attendeeDto = AttendeeUserDto.builder()
				.age(attendee.getUser().getAge())
				.contactNumber(attendee.getUser().getContactNumber())
				.userId(attendee.getUser().getUserId())
				.name(attendee.getUser().getName())
				.gender(attendee.getUser().getGender())
				.email(attendee.getUser().getEmail())
				.memeberShip(attendee.getMembershipStatus())
				.preferences(attendee.getPreferences())
				.tickets(attendee.getTickets())
				.feedbacks(feedbackDtoList)
				.notifications(notificationDtoList)
				.build();
		return attendeeDto;
	}

	// feedback to FeedbackUserDto
	public FeedbackUserDto feedbacktoFeedbackUserDto(Feedback feedback) {
		FeedbackUserDto feedbackDto = FeedbackUserDto.builder()
				.comment(feedback.getComment())
				.event_id(feedback.getEvent().getEventId())
				.rating(feedback.getRating())
				.submittedTimestamp(feedback.getSubmittedTimestamp())
				.feedbackId(feedback.getFeedbackId())
				.build();
		return feedbackDto;

	}

	// notification to notificationUserDto

	public NotificationUserDto notificationToNotificationUserDto(Notification notification) {
		NotificationUserDto notificationDto = NotificationUserDto.builder()
				.event_id(notification.getEvent().getEventId())
				.message(notification.getMessage())
				.sentTimeStamp(notification.getSentTimeStamp())
				.build();
		return notificationDto;

	}

	public void addPreference(String userId, String eventName) {
		List<Attendee> attendeeList = attendeeRepo.findAll();
		for (Attendee attendee : attendeeList) {
			if (attendee.getUserId().equals(userId)) {
				attendee.getPreferences().add(eventName);
				break;
			}
		}
	}

	public List<String> getPreference(String userId) throws AttendeeException {
		if (attendeeRepo.existsById(userId)) {
			List<Attendee> attendeeList = attendeeRepo.findAll();
			for (Attendee attendee : attendeeList) {
				if (attendee.getUserId().equals(userId)) {
					List<String> prefList = attendee.getPreferences();
					if (prefList.isEmpty()) {
						throw new AttendeeException("Attendee does not attend any event");
					}
					return prefList;
				}
			}
		}
		throw new AttendeeException("No attendee exists for the given Id: " + userId);
	}

	public String addMemberShip(String userId) throws AttendeeException {
		if (attendeeRepo.existsById(userId)) {
			Attendee attendee=attendeeRepo.findById(userId).get();
			attendee.setMembershipStatus(true);
			attendeeRepo.save(attendee);
			return "MemberShip is updated successfully!!";
			
		}
		throw new AttendeeException("No attendee exists for the given Id: " + userId);

	}

}
