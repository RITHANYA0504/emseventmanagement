package com.cts.ems.service;
 
import com.cts.ems.allinterface.TicketService;
import com.cts.ems.dto.ShowAllTicketsDto;
import com.cts.ems.dto.TicketEventDto;
import com.cts.ems.dto.TicketEventResponseDto;
import com.cts.ems.dto.TicketRequestDto;
import com.cts.ems.dto.TicketResponseDto;
import com.cts.ems.dto.TicketShareResponseDto;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.exception.AttendeeException;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.PaymentException;
import com.cts.ems.exception.TicketException;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.PaymentRepository;
import com.cts.ems.repository.TicketRepository;
import com.cts.ems.service.PaymentServiceImp;
 
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
 
import org.springframework.stereotype.Service;
 
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
@Service
@RequiredArgsConstructor
public class TicketServiceImp implements TicketService {
 
	private static final Logger logger = LoggerFactory.getLogger(TicketServiceImp.class);
 
	private final TicketRepository ticketRepo;
 
	private final AttendeeRepository attendeeRepo;
 
	private final EventRepository eventRepo;
 
	private final PaymentServiceImp paymentService;
	
	private final NotificationServiceImp notificationService;
 
	@Override
	public List<ShowAllTicketsDto> showAllTickets() {
		logger.info("Fetching all tickets");
		checkAndUpdateTicketToExpired();
		List<Ticket> tickets = ticketRepo.findAll();
		List<ShowAllTicketsDto> showTicketsDto = new ArrayList<ShowAllTicketsDto>();
		for (Ticket ticket : tickets) {
			showTicketsDto.add(showTickets(ticket));
		}
		return showTicketsDto;
	}
 
	@Override
	public List<ShowAllTicketsDto> showAllTicketsByEvent(String eventId) {
		logger.info("Fetching all tickets Based on EventId: {}", eventId);
		checkAndUpdateTicketToExpired();
		Event event = eventRepo.findById(eventId).orElseThrow(() -> new EventException("Event Not Found"));
		List<Ticket> tickets = ticketRepo.findByEvent(event);
		List<ShowAllTicketsDto> showTicketsDto = new ArrayList<ShowAllTicketsDto>();
		for (Ticket ticket : tickets) {
			showTicketsDto.add(showTickets(ticket));
		}
		return showTicketsDto;
	}
 
	@Override
	@Transactional
	public TicketResponseDto bookTicket(TicketRequestDto ticketRequest) {
		
		Event event = eventRepo.findById(ticketRequest.getEventId())
				.orElseThrow(() -> new EventException("Event Not Found"));
		
 
		Attendee attendee = attendeeRepo.findById(ticketRequest.getAttendeeId())
				.orElseThrow(() -> new AttendeeException("Attendee Not Found"));
 
		
		if(ticketRequest.getPaymentMethod().isBlank()) {
			throw new PaymentException("Payment Method Not found");
		}
 
		logger.info("Book ticket using ticketRequestDto for attendee Id{} and event Id{}", attendee.getUserId(),
				event.getEventId());
		boolean checkEventStatus = event.getEndDateTime().isBefore(LocalDateTime.now());
		if (checkEventStatus) {
			logger.warn("Event Has Started Already");
			throw new EventException("Event Has Started Already");
		}
 
		long booked = ticketRepo.countByEventAndStatus(event, "BOOKED");
		String status = "BOOKED";
		if (event.getMaxCount() > 0) {
 
			if (booked >= event.getMaxCount()) {
				status = "WAITLIST";
				logger.info("User has been added as \"WAITLIST\"");
			}
		}
 
		Optional<Ticket> existing = ticketRepo.findByEventAndAttendee(event, attendee);
		if (existing.isPresent() && !"CANCELED".equals(existing.get().getStatus())) {
			logger.warn("Ticket already exists for " + attendee.getUserId() + " , " + attendee.getUser().getName());
			throw new TicketException("Ticket already exists for " + attendee.getUser().getName());
		}
 
		Payment paymentRequest = Payment.builder().amount(event.getPrice())
				.paymentMethod(ticketRequest.getPaymentMethod()).build();
 
		Ticket ticket = Ticket.builder().event(event).attendee(attendee).status(status).payment(paymentRequest).build();
		Ticket saved = ticketRepo.save(ticket);
		Payment savedPayment = paymentService.processPayment(paymentRequest,ticket );
		logger.info("Ticket has been booked for user {}", attendee.getUserId());
		notificationService.sendTicketConfirmation(ticket, savedPayment);
		return getTicketDetails(saved.getTicketId());
 
	}
 
 
	@Override
	@Transactional
	public TicketResponseDto cancelTicket(String ticketId) {
		Ticket ticket = ticketRepo.findById(ticketId).orElseThrow(() -> new TicketException("Ticket Not Found"));
		if (!"BOOKED".equals(ticket.getStatus()) && !"WAITLIST".equals(ticket.getStatus())) {
			logger.warn("Ticket Has Already Cancelled Or Expired");
			throw new TicketException("Ticket Has Already Cancelled Or Expired ");
		}
 
		ticket.setStatus("CANCELED");
		logger.info("Ticket has been Cancelled for Ticket {}", ticketId);
 
		if (ticket.getPayment() != null && ticket.getPayment().getAmount() > 0) {
			paymentService.refundPayment(ticket.getPayment().getPaymentId());
			logger.info("Payment has been Refunded :" + ticketId);
 
		}
 
		Ticket saved = ticketRepo.save(ticket);
 
		Optional<Ticket> waitList = ticketRepo.findFirstByEventAndStatusOrderByBookingDateAsc(ticket.getEvent(),
				"WAITLIST");
		checkAndUpdateTicketToExpired();
		if (waitList.isPresent()) {
			Ticket updates = waitList.get();
			updates.setStatus("BOOKED");
			logger.info("Ticket has been Booked from WaitList " + updates.getAttendee().getUserId() + " Ticket Id "
					+ updates.getTicketId());
			ticketRepo.save(updates);
		}
		return getTicketDetails(saved.getTicketId());
	}
 
	@Override
	public TicketResponseDto getTicketDetails(String ticketId) {
		Ticket ticket = ticketRepo.findById(ticketId).orElseThrow(() -> new TicketException("Ticket Not Found"));
		checkAndUpdateTicketToExpired();
		logger.info("Get Ticked Details for Ticket " + ticketId);
		return responseToDto(ticket);
	}
 
	public TicketResponseDto getTicketDetailsByEventAndAttendee(String eventId, String attedeeId) {
		Attendee attendee = attendeeRepo.findById(attedeeId)
				.orElseThrow(() -> new AttendeeException("Attendee Not Found"));
		Event event = eventRepo.findById(eventId).orElseThrow(() -> new EventException("Event Not Found"));
		Ticket ticket = ticketRepo.findByEventAndAttendee(event, attendee)
				.orElseThrow(() -> new TicketException("No Tickets Found"));
		checkAndUpdateTicketToExpired();
		logger.info("Get Ticked Details By Event " + eventId + " and Attendee " + attedeeId);
		return responseToDto(ticket);
	}
 
	@Override
	public String getBookingStatus(String ticketId) {
		Ticket ticket = ticketRepo.findById(ticketId).orElseThrow(() -> new TicketException("Ticket Not Found"));
		checkAndUpdateTicketToExpired();
		logger.info("Get Booking status for ticket" + ticketId);
		return ticket.getStatus();
	}
 
	@Override
	public List<TicketEventDto> getAttendedEvents(String attendeeId) {
		Attendee attendee = attendeeRepo.findById(attendeeId)
				.orElseThrow(() -> new AttendeeException("Attendee Not Found"));
		List<Ticket> userTickets = ticketRepo.findByAttendee(attendee);
		checkAndUpdateTicketToExpired();
 
		if (userTickets.isEmpty()) {
			logger.warn("No Events Attended");
			throw new TicketException("No Events Attended");
		}
 
		List<TicketEventDto> fetched = new ArrayList<TicketEventDto>();
		for (Ticket ticketFetch : userTickets) {
			fetched.add(eventToDto(ticketFetch.getEvent()));
 
		}
 
		return fetched;
 
	}
 
	@Override
	public List<TicketResponseDto> getExpiredTicket() {
		checkAndUpdateTicketToExpired();
		List<TicketResponseDto> expiredTickets = new ArrayList<>();
		List<Ticket> allTickets = ticketRepo.findAll();
		for (Ticket tickets : allTickets) {
			if (tickets.getStatus().equals("EXPIRED")) {
				expiredTickets.add(responseToDto(tickets));
			}
 
		}
		logger.info("Get All the Expired Tickets ");
		return expiredTickets;
	}
 
	@Override
	public TicketShareResponseDto shareTicket(String ticketId) {
		Ticket ticket = ticketRepo.findById(ticketId).orElseThrow(() -> new TicketException("Ticket Not Found"));
 
		return TicketShareResponseDto.builder().ticketId(ticket.getTicketId())
				.attendeeName(ticket.getAttendee().getUser().getName()).eventName(ticket.getEvent().getName())
				.eventLocation(ticket.getEvent().getLocation()).status(ticket.getStatus())
				.bookingDate(formatDT(ticket.getUpdateDate()))
				.startDateTime(formatDT(ticket.getEvent().getStartDateTime()))
				.endDateTime(formatDT(ticket.getEvent().getEndDateTime())).build();
	}
 
	@Override
	@Transactional
	public void autoRefundWaitlist() {
		logger.info("Checking for waitlisted tickets in started events to refund...");
		List<Ticket> ticketList = ticketRepo.findAll();
		for (Ticket ticket : ticketList) {
			if (ticket.getStatus().equals("WAITLIST")
					&& ticket.getEvent().getEndDateTime().isBefore(LocalDateTime.now())) {
				Ticket ticketUpdated = ticketRepo.findById(ticket.getTicketId()).get();
				paymentService.refundPayment(ticket.getPayment().getPaymentId());
				ticketUpdated.setStatus("EXPIRED");
				ticketRepo.save(ticketUpdated);
 
			}
		}
	}
 
	private void checkAndUpdateTicketToExpired() {
		List<Ticket> allTickets = ticketRepo.findAll();
		for (Ticket ticket : allTickets) {
			boolean status = ticket.getEvent().getEndDateTime().isBefore(LocalDateTime.now());
			if (status) {
				if (ticket.getStatus().equals("BOOKED")) {
					ticket.setStatus("EXPIRED");
					ticketRepo.save(ticket);
					logger.warn("Ticket into has set to expire for ticketId " + ticket.getTicketId());
				}
 
			}
 
		}
	}
 
	private String formatDT(LocalDateTime dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy : HH:mm");
		return formatter.format(dateTime);
	}
 
	private TicketResponseDto responseToDto(Ticket ticket) {
 
		return TicketResponseDto.builder().ticketId(ticket.getTicketId())
				.bookingDate(formatDT(ticket.getUpdateDate()))
				.status(ticket.getStatus()).eventName(ticket.getEvent().getName()).price(ticket.getEvent().getPrice())
				.attendeeId(ticket.getAttendee().getUserId()).attendeeName(ticket.getAttendee().getUser().getName())
				.transactionId(ticket.getPayment().getPaymentId()).paymentStatus(ticket.getPayment().getPaymentStatus())
				.paymentMethod(ticket.getPayment().getPaymentMethod())
				.paymentDateTime(formatDT(ticket.getPayment().getPaymentDate())).build();
 
	}
 
	private ShowAllTicketsDto showTickets(Ticket ticket) {
		return ShowAllTicketsDto.builder().ticketId(ticket.getTicketId())
    			.ticketBookingDate(formatDT(ticket.getUpdateDate()))
				.ticketStatus(ticket.getStatus()).eventId(ticket.getEvent().getEventId())
				.eventName(ticket.getEvent().getName()).AttendeeId(ticket.getAttendee().getUserId())
				.AttendeeName(ticket.getAttendee().getUser().getName()).build();
	}
 
	private TicketEventDto eventToDto(Event event) {
 
		return TicketEventDto.builder().eventId(event.getEventId()).name(event.getName()).build();
	}
	    
	    private TicketEventResponseDto ticketResponseToDto(Ticket ticket) {
	    	TicketEventResponseDto response = TicketEventResponseDto.builder()
	    	.ticketId(ticket.getTicketId())
	    	.bookingDate(ticket.getBookingDate())
	    	.status(ticket.getStatus())
	    	.eventName(ticket.getEvent().getName())
	    	.price(ticket.getEvent().getPrice())
	    	.attendeeId(ticket.getAttendee().getUserId())
	    	.paymentId(ticket.getPayment().getPaymentId())
	    	.paymentStatus(ticket.getPayment().getPaymentStatus())
	    	.paymentMethod(ticket.getPayment().getPaymentMethod())
	    	.paymentDateTime(ticket.getPayment().getPaymentDate()).build();
	    	
	    	return response;
    
    }

		@Override
		public List<TicketEventResponseDto> getTicketByAttendeeId(String attendeeId)  {
			List<Ticket> ticketList = ticketRepo.findAll();
			List<TicketEventResponseDto> res = new ArrayList<>();
			for(Ticket t : ticketList) {
				if(attendeeId.trim().equals(t.getAttendee().getUserId().trim())) {
					TicketEventResponseDto dto = ticketResponseToDto(t);
					logger.info(dto.toString());
					
					res.add(dto);
				}
			}
			return res;
		}
	    

		
}
    
    			







