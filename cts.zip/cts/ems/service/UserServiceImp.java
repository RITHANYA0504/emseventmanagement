package com.cts.ems.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cts.ems.allinterface.UserService;
import com.cts.ems.dto.LoginUserDto;
import com.cts.ems.dto.UseruserDto;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.User;
import com.cts.ems.exception.UserException;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.OrganizerRepository;
import com.cts.ems.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
 
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImp implements UserService{
	
//--------------------Repository----------------------------------
	
	private final UserRepository userRepo;
	private final OrganizerServiceImp orgServ;
	private final AttendeeServiceImp attendeeServ;
	
//-----------------------User-----------------------------------
	
// sign up creating a user
	@Transactional
	public UseruserDto addUser(UseruserDto userDto) throws UserException {
 
	    if (userDto.getName() == null || userDto.getName().isEmpty()) {
	        throw new UserException("Name cannot be empty!");
	    }
	    if (userDto.getEmail() == null || userDto.getEmail().isEmpty()) {
	        throw new UserException("Email cannot be empty!");
	    }
	    if (userDto.getPassword() == null || userDto.getPassword().isEmpty()) {
	        throw new UserException("Password cannot be empty!");
	    }
	    if (userDto.getContactNumber() == null || userDto.getContactNumber().isEmpty()) {
	        throw new UserException("Contact Number cannot be empty!");
	    }
	    if (userDto.getAge() == 0) {
	        throw new UserException("Age cannot be empty!");
	    }
	    if (userDto.getGender() == null || userDto.getGender().isEmpty()) {
	        throw new UserException("Gender cannot be empty!");
	    }
 
	    List<User> users = userRepo.findAll();
	    for (User user : users) {
	        if (user.getEmail().equals(userDto.getEmail())) {
	            throw new UserException("Email already exists!!");
	        }
	        if (user.getContactNumber().equals(userDto.getContactNumber())) {
	            throw new UserException("Contact Number already exists!!");
	        }
	    }
 
	    User user = User.builder()
	            .name(userDto.getName())
	            .email(userDto.getEmail())
	            .password(userDto.getPassword())
	            .contactNumber(userDto.getContactNumber())
	            .age(userDto.getAge())
	            .gender(userDto.getGender())
	            .build();
	    Attendee attendee = Attendee.builder()
	            .user(user)
	            .membershipStatus(false)
	            .build();
	    Organizer organizer = Organizer.builder().user(user).build();
	    user.setOrganizer(organizer);
	    orgServ.addOrganizer(organizer);
		User res = userRepo.save(user);
		attendeeServ.addAttendee(attendee);
	    return userToUserDto(res);
	}
 
	
// deleting the user
	public String deleteUser(String userId) throws UserException {
	    Optional<User> userOpt = userRepo.findById(userId);
	    if (!userOpt.isPresent()) {
	    	log.error("An exception is thrown while deleting user with "+userId+" , thrown by deleteuser method.");
	        throw new UserException("No user exists with that ID");
	    }
	    attendeeServ.deleteById(userId);
	    userRepo.deleteById(userId);
	    log.info("An user with user id : "+userId+" is deleted by deleteuser method.");
	    return "Deleted the user with userid : "+userId;
	}
 
//updating user by id and Entire User
	public User updateUser(String user_id,UseruserDto user) throws UserException {
		log.info("Entering updateUser method with user_id: {}", user_id);
		Optional<User> useropt=userRepo.findById(user_id);
		if(!useropt.isPresent()) {
			log.error("No such account exists for user_id: "+ user_id);
			throw new UserException("No such account exist");
		}
		User u=useropt.get();
		log.debug("Updating user details for user_id: {}", user_id);
		u.setAge(user.getAge());
		u.setContactNumber(user.getContactNumber());
		u.setEmail(user.getEmail());
		u.setName(user.getName());
		u.setPassword(user.getPassword());
		u.setGender(user.getGender());
		log.info("User details updated successfully for user_id: {}", user_id);
		return userRepo.save(u);
	}
	
//get all User
	public List<UseruserDto> getAllUser() throws UserException{
		List<User> userList=userRepo.findAll();
		if(userList.isEmpty()) {
			log.error("User table does not contain any user");
			throw new UserException("User table does not contain any user");
		}
		List<UseruserDto> userDtoList=new ArrayList<>();
		log.debug("Getting all user....");
		for(User user : userList) {
			UseruserDto userDto=userToUserDto(user);
			userDtoList.add(userDto);
		}
		log.info("All users returned successfully.");
		return userDtoList;
	}	
	
//login using username and password
	public UseruserDto login(LoginUserDto login) throws UserException {
		List<User> userList=userRepo.findAll();
		for(User user:userList) {
			if(user.getName().equals(login.getName()) && user.getPassword().equals(login.getPassword())) {
				log.info("Login successfullty");
				return userToUserDto(user);
			}
		}
		log.error("No user exist for username and password");
		throw new UserException("User does not exist");
	}
	
//forgot password by using user fields
	public User forgotPassword(String userName,String email,String number,String newPassword)throws UserException {
		List<User> userList=userRepo.findAll();
		for(User user:userList) {
			if(user.getName().equals(userName) && user.getContactNumber().equals(number) && user.getEmail().equals(email)) {
				user.setPassword(newPassword);
				userRepo.save(user);
				log.info("Password changed successfully by forget password method");
				return user;
			}
		}
		log.error("No user exist to change password");
		throw new UserException("User does not exist");
	}
	
	
//view user by user id
	public UseruserDto getUser(String userId) throws UserException {
        log.info("Entering getUserDto method with userId: {}", userId);
		Optional<User> useropt=userRepo.findById(userId);
		if(useropt.isPresent()) {
			User user=useropt.get();
			UseruserDto userDto= userToUserDto(user);
			log.info("UserDto created successfully for userId: {}", userId);
			return userDto;
		}
		log.error("User does not exist for userId: {}", userId);
		throw new UserException("User does not exist");
	}
	
//update userName by user id
	public User updateName(String id,String name) throws UserException{
		log.info("Entering updateUser method with id: {}", id);
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		log.debug("Updating user name for id: {}", id);
		User user1=user.get();
		user1.setName(name);
		return userRepo.save(user1);
	}
	
//update user email by using user id
	public User updateEmail(String id,String email) throws UserException{
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		User user1=user.get();
		user1.setEmail(email);
		return userRepo.save(user1);
	}
	
//update user contact number using user id
	public User updateContactNumber(String id,String number) throws UserException{
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		User user1=user.get();
		user1.setContactNumber(number);
		return userRepo.save(user1);
	}
	
//update user age by using user id
	public User updateAge(String id,int age) throws UserException{
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		User user1=user.get();
		user1.setAge(age);
		return userRepo.save(user1);
	}
	
//update user gender by using user id
	public User updateGender(String id,String gender) throws UserException{
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		User user1=user.get();
		user1.setGender(gender);
		return userRepo.save(user1);
	}
	
//update user password by using user id
	public User updatePassword(String id,String password) throws UserException {
		Optional<User> user=userRepo.findById(id);
		if(!user.isPresent()) {
			log.error("User does not exist for id: {}", id);
			throw new UserException("User does not exist");
		}
		User user1=user.get();
		user1.setPassword(password);
		return userRepo.save(user1);
	}
	
 
//------------------for EventService--------------------------------------	
	public User getUserById(String userId) throws UserException {
		Optional<User> user=userRepo.findById(userId);
		if(user.isPresent()) {
			return user.get();
		}
		throw new UserException("User does not exist");
	}
	public List<User> getAllUsers(){
		return userRepo.findAll();
	}
	
	public boolean userIsPresent(String id) {
		Optional<User> user = userRepo.findById(id);
		return user.isPresent();
	}
 
	
	 //user to userDto
	public UseruserDto userToUserDto(User user) {
		UseruserDto userDto=UseruserDto.builder()
					.userId(user.getUserId())
					.age(user.getAge())
					.contactNumber(user.getContactNumber())
					.email(user.getEmail())
					.gender(user.getGender())
					.name(user.getName())
					.password(user.getPassword())
					.build();
		return userDto;
		}
 
}
 