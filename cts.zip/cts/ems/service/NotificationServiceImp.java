package com.cts.ems.service;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;
 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.cts.ems.allinterface.EventService;
import com.cts.ems.allinterface.NotificatioService;
import com.cts.ems.dto.NotificationRequestDTO;
import com.cts.ems.dto.NotificationResponseDTO;
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Feedback;
import com.cts.ems.entity.Notification;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.exception.AttendeeException;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.NotificationException;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.NotificationRepository;
 
import lombok.Builder;
 
import lombok.extern.slf4j.Slf4j;
@Builder
@Service
@Slf4j
public class NotificationServiceImp implements NotificatioService{
	
    
	@Autowired
	NotificationRepository nRepo;
	
	@Autowired
	EventRepository eRepo;
	
	@Autowired
	EventServiceImp eServ;
	
	@Autowired
	AttendeeServiceImp aServ;
	
	@Autowired
	AttendeeRepository aRepo;
	
	public void sendNotification(Event event,Attendee attendee,String msg)
	{
		Notification notification = Notification.builder()
				.event(event)
				.attendee(attendee)
				.message(msg)
				.sentTimeStamp(LocalDateTime.now())
				.build();
		nRepo.save(notification);
		log.info("Notification"+msg+" has been sent");
	}
	
	public void sendTicketConfirmation(Ticket ticket,Payment payment)
	{
		String message = "TICKET CONFIRMATION!!!,Your Ticket ID :"+ticket.getTicketId()+" for the event "+ticket.getEvent().getName()+" has been confirmed on "+ticket.getEvent().getStartDateTime()+" and your Payment Status is "+payment.getPaymentStatus();
		sendNotification(ticket.getEvent(), ticket.getAttendee(), message);
		log.info("Ticket Confirmation for "+ticket.getTicketId()+"is confirmed");
	}
	
	public void sendPaymentConfirmation(Payment payment)
	{
		String message = "PAYMENT CONFIRMATION!!!,Your Payment ID :"+payment.getPaymentId()+" with payment status "+payment.getPaymentStatus()+"has been Registered!!!";
		sendNotification(payment.getTicket().getEvent(), payment.getTicket().getAttendee(), message);
		log.info("Payment Confirmation for "+payment.getPaymentId()+"is confirmed");
	}
	
 
 
	@Override
	public List<NotificationResponseDTO> findAllNotification()
	{
		log.info("Fetching all notifications");
		return nRepo.findAll().stream()
				.map(this::convertToResponseDTO)
				.collect(Collectors.toList());
		
	}
	
	 public NotificationResponseDTO getNotificationById(String notificationId) throws NotificationException{
		    log.info("Fetching notification by ID: {}", notificationId);
	        Optional<Notification> notification = nRepo.findById(notificationId);
	        if(notification.isPresent())
	        {
	        	log.info("Notification found: {}", notification.get());
	        	return notification.map(this::convertToResponseDTO).orElse(null);
	        }
	        else
	        {
	        	log.error("Notification not found for ID: {}", notificationId);
	        	throw new NotificationException("Sorry Couldn't Find the Notification");
	        }
	        
	        
	    }
	
	    public NotificationResponseDTO addNotification(NotificationRequestDTO requestDTO)
	    {
	    	log.info("Adding new notification");
	        Notification notification = convertToEntity(requestDTO);
	        Notification saved=nRepo.save(notification);
	        log.info("Notification added and saved: {}", saved);
	        return convertToResponseDTO(saved);
	    }
	
	
	
	  
	
	    public NotificationResponseDTO updateNotificationById(String notificationId, NotificationRequestDTO updatedRequestDTO) throws NotificationException, EventException, AttendeeException {
	        Optional<Notification> optionalNotification = nRepo.findById(notificationId);
	        if (optionalNotification.isPresent()) {
	            log.info("Updating notification by ID: {}", notificationId);
	            Notification notification = optionalNotification.get();
	            notification.setMessage(updatedRequestDTO.getMessage());
	            notification.setSentTimeStamp(updatedRequestDTO.getSentTimeStamp());
 
	            Optional<Event> optionalEvent = eRepo.findById(updatedRequestDTO.getEvent_id());
	            if (optionalEvent.isPresent()) {
	                notification.setEvent(optionalEvent.get());
	            } else {
	                log.error("Event not found for ID: {}", updatedRequestDTO.getEvent_id());
	                throw new EventException("Sorry Couldn't Find the Event: " + updatedRequestDTO.getEvent_id());
	            }
 
	            Optional<Attendee> optionalAttendee = aRepo.findById(updatedRequestDTO.getAttendee_id());
	            if (optionalAttendee.isPresent()) {
	                notification.setAttendee(optionalAttendee.get());
	            } else {
	                log.error("Attendee not found for ID: {}", updatedRequestDTO.getAttendee_id());
	                throw new AttendeeException("Attendee not found for ID: " + updatedRequestDTO.getAttendee_id());
	            }
 
	            Notification saved = nRepo.save(notification);
	            log.info("Notification updated and saved: {}", saved);
	            return convertToResponseDTO(saved);
	        } else {
	            log.error("Notification not found for ID: {}", notificationId);
	            throw new NotificationException("Sorry Couldn't Find the Notification");
	        }
	    }
 
 
 
 
	    public String deleteNotificationById(String notificationId) throws NotificationException{
	        if (nRepo.existsById(notificationId)) {
	            nRepo.deleteById(notificationId);
	            log.info("Deleting notification by ID: {}", notificationId);
	            return "Deleted Successfully";
	        }
	        else
	        {
	        log.error("Notification not found for ID: {}", notificationId);
	        throw new NotificationException("Sorry Couldn't Find the Notification");
	       
	        }
	    }
	
	    public NotificationResponseDTO convertToResponseDTO(Notification notification) {
	    	log.debug("Converting Notification to NotificationResponseDTO: {}", notification);
	        return NotificationResponseDTO.builder()
	            .message(notification.getMessage())
	            .sent_time_stamp(notification.getSentTimeStamp())
	            .eventId(notification.getEvent().getEventId())
	            .membershipStatus(notification.getAttendee().getMembershipStatus())
	            .EVENT_name(notification.getEvent().getName())
	            .userId(notification.getAttendee().getUserId())
	            .Email(notification.getAttendee().getUser().getEmail())
	            .ContactNumber(notification.getAttendee().getUser().getContactNumber())
	            .NotificationId(notification.getNotificationId())
	            .attendee_Id(notification.getAttendee().getUserId())
	            .build();
	    }
 
	
	    public Notification convertToEntity(NotificationRequestDTO requestDTO) {
	    	log.debug("Converting NotificationRequestDTO to Notification: {}", requestDTO);
	        Event event = eServ.getEventEntityById(requestDTO.getEvent_id());
	        Attendee attendee = aServ.getAttendeeEntityById(requestDTO.getAttendee_id());
 
	        return Notification.builder()
	            .message(requestDTO.getMessage())
	            .sentTimeStamp(requestDTO.getSentTimeStamp())
	            .notificationId(requestDTO.getNotification_id())
	            .event(event)
	            .attendee(attendee)
	            .build();
	    }

	
	
 
 
}
 