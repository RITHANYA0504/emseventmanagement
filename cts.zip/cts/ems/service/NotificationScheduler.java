package com.cts.ems.service;
 
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import com.cts.ems.entity.Attendee;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Notification;
import com.cts.ems.entity.Ticket;
import com.cts.ems.repository.AttendeeRepository;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.NotificationRepository;
 
import jakarta.transaction.Transactional;
import lombok.Builder;
 
@Builder
@Service
public class NotificationScheduler {
 
    private static final Logger logger = LoggerFactory.getLogger(NotificationScheduler.class);
 
    @Autowired
    EventRepository eRepo;
    @Autowired
    NotificationRepository nRepo;
    @Autowired
    AttendeeRepository aRepo;
 
    @Transactional
    @Scheduled(fixedRate = 60000)
    public void checkAndSendNotifications() {
        logger.info("Starting checkAndSendNotifications at {}", LocalDateTime.now());
        List<Event> events = eRepo.findAllEventsWithTickets();
        LocalDateTime now = LocalDateTime.now();
        for (Event event : events) {
            LocalDateTime eventDateTime = event.getStartDateTime();
            LocalDateTime eventEndTime = event.getEndDateTime();
            long minutesToEvent = Duration.between(now, eventDateTime).toMinutes();
            long minutesToEventEnd = Duration.between(now, eventEndTime).toMinutes();
            String message = null;
            logger.info("Checking event: {} at {}", event.getName(), now);
            logger.info("Event start time: {}, Event end time: {}", eventDateTime, eventEndTime);
            logger.info("Minutes to event: {}, Minutes to event end: {}", minutesToEvent, minutesToEventEnd);
 
            if (minutesToEvent == 1440) {
                message = "Reminder: Your event " + event.getName() + " is tomorrow!";
            } else if (minutesToEvent == 30) {
                message = "Reminder: Your event " + event.getName() + " is in 30 minutes!";
            } else if (minutesToEvent == 0) {
                message = "Reminder: Your event " + event.getName() + " is starting now!";
            } else if (minutesToEventEnd == 0) {
                message = "FEEDBACK REMINDER: Your event " + event.getName() + " has ended. Please fill out the feedback form!";
            }
 
            if (message != null) {
                logger.info("Generated message: {}", message);
                List<Attendee> attendees = aRepo.findAll();
                for (Attendee attendee : attendees) {
                    logger.info("Checking attendee: {}", attendee.getUserId());
                    List<Ticket> tickets = event.getTickets();
                    for (Ticket t : tickets) {
                        logger.info("Checking ticket for attendee: {}", t.getAttendee().getUserId());
                        if (t.getAttendee().getUserId().equals(attendee.getUserId())) {
                            logger.info("Attendee {} has a ticket for event {}", attendee.getUserId(), event.getName());
                            if (!nRepo.existsByEventAndAttendeeAndMessage(event, attendee, message)) {
                                Notification notification = Notification.builder()
                                        .message(message)
                                        .sentTimeStamp(now)
                                        .event(event)
                                        .attendee(attendee)
                                        .build();
                                nRepo.save(notification);
                                logger.info("Notification sent to {}: {}", attendee.getUserId(), message);
                            } else {
                                logger.info("Notification already exists for {}: {}", attendee.getUserId(), message);
                            }
                        }
                    }
                }
            }
        }
        logger.info("Finished checkAndSendNotifications at {}", LocalDateTime.now());
    }
}