package com.cts.ems.service;
 
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.ems.allinterface.EventService;
import com.cts.ems.allinterface.OrganizerService;
import com.cts.ems.dto.EventUserDto;
import com.cts.ems.dto.OrganizerUserDto;
import com.cts.ems.dto.PaymentUserDto;
import com.cts.ems.entity.Event;
import com.cts.ems.entity.Organizer;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.entity.User;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.repository.EventRepository;
import com.cts.ems.repository.OrganizerRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
 
@Service
@RequiredArgsConstructor
public class OrganizerServiceImp implements OrganizerService {
	
	
	private final OrganizerRepository organizerRepo;
		
	private final EventRepository eventRepo;
 
	
	public Organizer addOrganizer(Organizer org) {
		return organizerRepo.save(org);
	}
	
	public boolean isOrganizerPresent(String string) {
		return organizerRepo.existsById(string);
	}
	
	//get Organizer by using organizer id
			public Optional<Organizer> getOrganizerEnityById(String id)throws OrganizerException {
				if(!organizerRepo.existsById(id)) {
					throw new OrganizerException("No organizer exists");
				}
		        return organizerRepo.findById(id);
		    }
	
	//-----------------------------Organizer-----------------------------------------
	
	//get Organizer by using organizer id
		public OrganizerUserDto getOrganizerById(String id)throws OrganizerException {
			if(!organizerRepo.existsById(id)) {
				throw new OrganizerException("No organizer exists");
			}
	        Organizer organizer = organizerRepo.findById(id).orElse(null);
	        OrganizerUserDto organizerDto =organizerToOrganizerUserDto(organizer);
	        return organizerDto;
	    }
 
	//get All Organizer
	    public List<OrganizerUserDto> getAllOrganizers() throws OrganizerException{
	        List<Organizer> organizers = organizerRepo.findAll();
	        List<OrganizerUserDto> organizerDtos = new ArrayList<>();
	        if(organizers.isEmpty()) {
	        	throw new OrganizerException("Organizer table is empty");
	        }
	        for (Organizer org : organizers) {
	            OrganizerUserDto organizerDto =organizerToOrganizerUserDto(org);
	            organizerDtos.add(organizerDto);
	        }
	        return organizerDtos;
	    }
	    
	// delete Organizer by using Organizer Id
	    @Transactional
	    public String deleteOrganizerById(String id) throws OrganizerException, EventException {
	        if (organizerRepo.existsById(id)) {
	        	List<Event> events=eventRepo.findAll();
	        	for(Event event: events) {
	        		if(event.getOrganizer().getUserId().equals(id)) {
	                	eventRepo.deleteById(event.getEventId());
	        		}
	        	}
	            organizerRepo.removeOrganizer(id);
	            return "Organizer with ID " + id + " deleted successfully.";
	        }
	        throw new OrganizerException("No user exists");
	    }
	  
	
	    
	 // get all payments by using organizer Id
	    public List<PaymentUserDto> getAllPayments(String organizerId ,String eventId) throws OrganizerException{
	    	if(!organizerRepo.existsById(organizerId)) {
	    		throw new OrganizerException("No organizer exist");
	    	}
	    	List<Event> eventList=organizerRepo.findById(organizerId).get().getEventsOrganized();
	    	String event_id="";
	    	List<Ticket> tickets=new ArrayList<>();
	    	for(Event event : eventList) {
	    		if(event.getEventId().equals(eventId)) {
	    			event_id=event.getEventId();
	    			tickets=event.getTickets();
	    			break;
	    		}
	    	}
	    	if(event_id==null) {
	    		throw new OrganizerException("No event exist for the given organizer id");
	    	}
	    	List<PaymentUserDto> paymentDtoList=new ArrayList<>();
	    	for(Ticket ticket : tickets) {
	    		Payment payment=ticket.getPayment();
	    		PaymentUserDto paymentDto=paymentToPaymentUserDto(payment);
	    		paymentDtoList.add(paymentDto);
	    	}
	    	
	        return paymentDtoList;
	    }
 
	    //organizer to organizerUserDto
	    	public OrganizerUserDto organizerToOrganizerUserDto(Organizer organizer) {
	    		 User user=organizer.getUser();
	            List<EventUserDto> eventDtoList=new ArrayList<>();
	            List<Event> events =organizer.getEventsOrganized();
	            for(Event event : events) {
	          	  EventUserDto eventDto=eventToEventUserDto(event);
	            	eventDtoList.add(eventDto);   
	            }
	            OrganizerUserDto organizerDto =OrganizerUserDto.builder()
	            		.age(user.getAge())
	            		.contactNumber(user.getContactNumber())
	            		.email(user.getEmail())
	            		.gender(user.getGender())
	            		.name(user.getName())
	            		.userId(user.getUserId())
	            		.events(eventDtoList)
	            		.build();
	            return organizerDto;
	    	}
	    	
	    //payment to paymentUserDto
	    	public PaymentUserDto paymentToPaymentUserDto(Payment payment) {
	    		PaymentUserDto paymentDto=PaymentUserDto.builder()
	   				.amount(payment.getAmount())
	   				.paymentDate(payment.getPaymentDate())
	   				.paymentMethod(payment.getPaymentMethod())
	   				.paymentId(payment.getPaymentId())
	   				.paymentStatus(payment.getPaymentStatus())
	   				.build();
	    		return paymentDto;
	    	}
	    	 //event to eventUserDto
	     	public EventUserDto eventToEventUserDto(Event event) {
	     		EventUserDto eventDto=EventUserDto.builder()
	        			.category(event.getCategory())
	        			.eventId(event.getEventId())
	        			.location(event.getLocation())
	        			.name(event.getName())
	        			.regDate(event.getRegDate())
	        			.build();
	     		return eventDto;
	     	}
	
}
 
 