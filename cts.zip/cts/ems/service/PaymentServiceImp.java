package com.cts.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ems.allinterface.PaymentService;
import com.cts.ems.dto.PaymentResponseDto;
import com.cts.ems.entity.Payment;
import com.cts.ems.entity.Ticket;
import com.cts.ems.exception.PaymentException;
import com.cts.ems.repository.PaymentRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class PaymentServiceImp implements PaymentService {
	
	private final PaymentRepository paymentRepository;
	private final NotificationServiceImp notificationService;

	@Override
	public Payment processPayment(Payment payment, Ticket tic) {
		log.info("Initiating payment processing for ticketId={} and method={}", payment.getAmount(), // payment.getTicket().getTicketId(),
				payment.getPaymentMethod());
//		validatePaymentDetails(payment);
 
		payment.setPaymentStatus("Completed");
 
		payment.setTicket(tic);
		log.info("Payment successfully processed | paymentId={}, status={}, amount={}", payment.getPaymentId(),
				payment.getPaymentStatus());
		notificationService.sendPaymentConfirmation(payment);
		return payment;
	}

	@Override
	public List<Payment> getAllPayment() {
		log.debug("Fetching all payment details");
		List<Payment> payments = paymentRepository.findAll();
		
		return payments;
	}

	@Override
	public Payment getPaymentById(String paymentId) {
		log.debug("Fetching payment details | paymentId={}", paymentId);
		Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> {
			log.error("Payment not found for ID: {}", paymentId);
			return new PaymentException("Payment Not Found");
		});

		return payment;
	}


	@Override
	public String trackPaymentStatus(String paymentId) {
		log.debug("Tracking payment status | paymentId={}", paymentId);
		Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> {
			log.error("Payment not found for ID: {}", paymentId);
			return new PaymentException("Payment Not Found");
		});

		switch (payment.getPaymentStatus()) {
		case "Completed":
			log.info("Payment completed | paymentId={}", paymentId);
			return "PAYMENT COMPLETED";
		case "Refunded":
			log.info("Payment refunded | paymentId={}", paymentId);
			return "PAYMENT REFUNDED";
		default:
			log.warn("Payment pending or unknown status | paymentId={}", paymentId);
			return "PAYMENT PENDING";
		}
	}

	@Override
	public PaymentResponseDto generateReport(String paymentId) {
		log.info("Generating payment report | paymentId={}", paymentId);
		Payment payment = paymentRepository.findById(paymentId).get();
		PaymentResponseDto dto = responseToDto(payment);
		log.debug("Generated report for paymentId={}", paymentId);
		return dto;
	}

	@Override
	public boolean isPaymentSuccessful(String paymentId) {
		log.debug("Checking if payment is successful | paymentId={}", paymentId);
		boolean isSuccessful = "Completed".equalsIgnoreCase(getPaymentById(paymentId).getPaymentStatus());
		log.info("Payment success status for paymentId={} is {}", paymentId, isSuccessful);
		return isSuccessful;
	}

	@Override
	public List<PaymentResponseDto> getPaymentsByAttendeeId(String attendeeId) {
		log.info("Fetching payments for attendeeId={}", attendeeId);
		List<Payment> payments = paymentRepository.getPaymentsByAttendeeId(attendeeId);
		if (payments.isEmpty()) {
			throw new PaymentException("No payments found for attendeeId=" + attendeeId);
		}
		List<PaymentResponseDto> responsePayment = new ArrayList<PaymentResponseDto>();
		for (Payment payment : payments) {

			responsePayment.add(responseToDto(payment));
		}
		log.info("Found {} payments for attendeeId={}", payments.size(), attendeeId);
		return responsePayment;
	}

	@Override
	public List<PaymentResponseDto> getPaymentsByEventId(String eventId) {
		log.info("Fetching payments for eventId={}", eventId);

		List<Payment> payments = paymentRepository.getPaymentsByEventId(eventId);
		if (payments.isEmpty()) {
			throw new PaymentException("No payments found for eventId=" + eventId);
		}
		List<PaymentResponseDto> responsePayment = new ArrayList<PaymentResponseDto>();
		for (Payment payment : payments) {

			responsePayment.add(responseToDto(payment));
		}
		log.info("Found {} payments for eventId={}", payments.size(), eventId);
		return responsePayment;
	}

	@Transactional
	public PaymentResponseDto refundPayment(String paymentId) {
		log.info("Initiating refund for paymentId={}", paymentId);
 
		Optional<Payment> optionalPayment = paymentRepository.findById(paymentId);
		if (optionalPayment.isEmpty()) {
			log.error("Refund failed | paymentId={} not found", paymentId);
			throw new PaymentException("Payment Not Found");
		}
		Payment payment = optionalPayment.get();
		if ("Refunded".equals(payment.getPaymentStatus())) {
			throw new PaymentException("Payment is already refunded.");
		}
		paymentRepository.updatePaymentStatus(paymentId, "Refunded");
		log.info("Refund successful | paymentId={} | newStatus=Refunded", paymentId);
		payment.setPaymentStatus("Refunded"); // Ensure payment entity is updated
		return responseToDto(payment);
	}

	@Override
	public void validatePaymentDetails(Payment payment) {
//		if (payment.getPaymentMethod() == null || payment.getPaymentMethod().isEmpty()) {
//			throw new PaymentException("Payment method is required.");
//		}
//
//		if (payment.getTicket() == null ) {
//			throw new PaymentException("Valid ticket and attendee information is required.");
//		}
	}

	@Override
	public PaymentResponseDto responseToDto(Payment payment) {

		PaymentResponseDto response = PaymentResponseDto.builder()
				.attendeeId(payment.getTicket()
				.getAttendee().getUserId())
				.attendeeName(payment.getTicket().getAttendee().getUser().getName())
				.eventName(payment.getTicket().getEvent().getName()).ticketId(payment.getTicket().getTicketId())
				.price(payment.getTicket().getEvent().getPrice()).status(payment.getTicket().getStatus())
				.paymentId(payment.getPaymentId()).paymentStatus(payment.getPaymentStatus())
				.paymentMethod(payment.getPaymentMethod()).paymentDateTime(payment.getPaymentDate()).build();

		return response;
	}
	
	

}
