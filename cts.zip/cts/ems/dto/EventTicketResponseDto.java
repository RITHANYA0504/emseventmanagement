package com.cts.ems.dto;
import java.time.LocalDateTime;
import java.util.List;

import com.cts.ems.entity.Event.EventBuilder;

import lombok.Builder;
import lombok.Data;
 
@Data
@Builder
public class EventTicketResponseDto {
	

		private String eventId;
		private String eventName;
		private String category;	
		private String location;
		private LocalDateTime regDate;
		private Integer maxCount;
		private LocalDateTime startDateTime;
		private LocalDateTime endDateTime;
		private Double price;
		private String organizerId;
		private List<EventTicketResponseDto> tickets;

	
}