package com.cts.ems.dto;

import lombok.Data;

@Data
public class LoginEventDto {
	
	String name;
	String password;
	

}