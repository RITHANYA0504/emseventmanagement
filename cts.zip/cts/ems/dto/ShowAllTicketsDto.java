package com.cts.ems.dto;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Builder
@Getter
@Setter
public class ShowAllTicketsDto {
	private String ticketId;
    private String ticketBookingDate;
    private String eventId;
    private String eventName;
    private String ticketStatus;
    private String AttendeeId;
    private String AttendeeName;
    // Event Id;
    // Event Name;
    // Event Date;
    // Ticket Status;

}
