package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TicketResponseDto {
	
	private String ticketId;
	private String bookingDate;
	private String status;
	
	private String eventName;
	private Double price;
	
	private String attendeeId;
	private String attendeeName;
	
	private String transactionId;
	private String paymentStatus;
	private String paymentMethod;
	private String paymentDateTime;
}
