package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class TicketEventResponseDto {

	private String ticketId;
	private String status;
	private String eventName;
	private Double price;
	private String attendeeId;
	private String paymentId;
	private String attendeeName;
	private String paymentStatus;
	private String paymentMethod;
	private LocalDateTime paymentDateTime;
	private LocalDateTime bookingDate;
}
