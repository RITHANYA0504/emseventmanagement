package com.cts.ems.dto;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TicketShareResponseDto {
	private String ticketId;
	private String attendeeName;
	private String eventName;
	private String eventLocation;
	private String status;
	private String bookingDate;
	private String startDateTime;
	private String endDateTime;

}
