package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FeedbackResponseDTO {
	
	private String feedbackId;
	
	private int rating;
	
	private String comments;
	
	private LocalDateTime timeStamp;
	
	private String eventId;
	
	private String attendeeId;
}
