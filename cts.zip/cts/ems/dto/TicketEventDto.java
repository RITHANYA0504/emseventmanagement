package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TicketEventDto {
	
	
	private String eventId;
    private String name;
//    private String category;
//    private String location;
//    private LocalDateTime registrationDate;
//    private Integer organizerId;
//    private LocalDateTime startDateTime;
//    private LocalDateTime endDateTime;
//    private Double price;
//    private Integer maxCount;
}

