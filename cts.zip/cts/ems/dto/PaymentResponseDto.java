package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDto {
	private String attendeeId;
	private String attendeeName;
	private String eventName;
	private String ticketId;
	private Double price;
	private String status;
	
	private String paymentId;
	private String paymentStatus;
	private String paymentMethod;
	private LocalDateTime paymentDateTime;




}
