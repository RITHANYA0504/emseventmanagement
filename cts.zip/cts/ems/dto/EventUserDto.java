package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EventUserDto {
	
	
    private String eventId;
    private String name;
    private String category;
    private String location;
    private LocalDateTime regDate;


}
