package com.cts.ems.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.cts.ems.entity.Ticket;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EventResponseDto {
	private String eventId;

    private String name;

    private String category;

    private String location;

    private LocalDateTime regDate;


    private Integer maxCount;

    private LocalDateTime  startDateTime;

    private LocalDateTime endDateTime;

    private Double price;

    private String organizerId;
    
    private List<TicketEventResponseDto> tickets;
    
    
    
    
}
