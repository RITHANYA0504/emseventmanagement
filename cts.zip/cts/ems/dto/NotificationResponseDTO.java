package com.cts.ems.dto;


import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationResponseDTO {
	

	private String eventId;
	private String NotificationId;
	private LocalDateTime sent_time_stamp;
	private String message;
	private String ContactNumber;
	private String Email;
	private boolean membershipStatus;
	private String EVENT_name;
	private String attendee_Id;
	private String userId;
}
