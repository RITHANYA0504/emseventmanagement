package com.cts.ems.dto;

import java.util.List;


import com.cts.ems.entity.Ticket;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendeeUserDto {
	
	private String userId;
    private String name;
    private String email;
    private String contactNumber;
    private Integer age;
    private String gender;
    private boolean memeberShip;
    private List<String> preferences;
    private List<Ticket> tickets;
    private List<FeedbackUserDto> feedbacks;
    private List<NotificationUserDto> notifications;

}
