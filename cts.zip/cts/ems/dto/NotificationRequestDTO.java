package com.cts.ems.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationRequestDTO {
	
	private String attendee_id;
	private String event_id;
	private String notification_id;
	private LocalDateTime sentTimeStamp;
	private String message;


}

