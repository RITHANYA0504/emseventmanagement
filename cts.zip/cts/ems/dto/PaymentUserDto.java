package com.cts.ems.dto;

import java.time.LocalDateTime;

import com.cts.ems.entity.Ticket;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentUserDto {
	
    private String paymentStatus;
    private String paymentMethod;
    private double amount;
    private LocalDateTime paymentDate;
    private String paymentId;


}
