package com.cts.ems.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.commons.lang3.RandomStringUtils;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "event_tbl")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Event {

    @Id
    private String  eventId;
  
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(eventId == null) {
    		eventId=RandomStringUtils.randomAlphanumeric(3);
    		eventId+=RandomStringUtils.randomNumeric(2);
    	}
    }

    @NotNull(message = "Event Name is required")
    private String name;

    @NotNull(message = "Category is required")
    private String category;

    @NotNull(message = "Location is required")
    private String location;

    @NotNull(message = "Registration Date is required")
    private LocalDateTime regDate;

    @NotNull(message = "Message cannot be Null")
    @Min(value = 0,message = "If less than 0 that's no possible ")
    private Integer maxCount;

    @NotNull(message = "Start date and time is required")
    private LocalDateTime  startDateTime;

    @NotNull(message = "End date and time is required")
    private LocalDateTime endDateTime;

    @NotNull(message = "Event price is required")
    private Double price;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "organizer_id")
    
    private Organizer organizer;

    @OneToMany(fetch = FetchType.EAGER,mappedBy = "event",cascade = CascadeType.ALL,orphanRemoval = true)
    @JsonManagedReference
    private List<Ticket> tickets;

    @OneToMany(mappedBy = "event",cascade = CascadeType.ALL,orphanRemoval = true)
    @JsonManagedReference
    private List<Feedback> feedbacks;

    @OneToMany(mappedBy = "event",cascade = CascadeType.ALL,orphanRemoval = true)
    @JsonManagedReference
    private List<Notification> notifications;
}
