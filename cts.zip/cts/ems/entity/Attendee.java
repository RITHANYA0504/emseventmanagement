package com.cts.ems.entity;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="attendee_tbl")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Attendee {
	
	@Id
	String userId;

	@OneToOne
	@MapsId
	@JoinColumn(name = "organizer_id")
	User user;
   
    @Column(name="membership_status")
    private Boolean membershipStatus;

    @ElementCollection
    @CollectionTable(name="attendee_preference_tbl",joinColumns = @JoinColumn(name = "attendee_id"))
    @Column(name = "preference")
    private List<String> preferences;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Ticket> tickets;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Feedback> feedbacks;

    @OneToMany(mappedBy = "attendee",cascade = CascadeType.PERSIST,orphanRemoval = true)
    @JsonManagedReference
    private List<Notification> notifications;
}
