package com.cts.ems.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.apache.commons.lang3.RandomStringUtils;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "payment_tbl")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {
    @Id
    private String paymentId;
    
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(paymentId == null) {
    		paymentId=RandomStringUtils.randomAlphanumeric(3);
    		paymentId+=RandomStringUtils.randomNumeric(2);
    	}
    }

    @NotNull(message = "Payment date is required")
    @CreationTimestamp
    private LocalDateTime paymentDate;

    @NotNull(message = "Amount is required")
    private double amount;

    @NotNull(message = "Payment Method is required")
    private String paymentMethod;


    @NotNull(message = "Payment Status is required")
    private String paymentStatus;

    @OneToOne(mappedBy = "payment",cascade = CascadeType.ALL)
    private Ticket ticket;
}

