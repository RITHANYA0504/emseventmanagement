package com.cts.ems.entity;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.apache.commons.lang3.RandomStringUtils;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Builder
@Entity
@Table(name = "notification_tbl")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
	
	@Id
	private String notificationId;

	@SuppressWarnings("deprecation")
	@PrePersist
	public void generatedId() {
		if (notificationId == null) {
			notificationId = RandomStringUtils.randomAlphanumeric(3);
			notificationId += RandomStringUtils.randomNumeric(2);
		}
	}

	@NotNull(message = "Message is required")
	private String message;

	@NotNull(message = "Sent timestamp is required")
	private LocalDateTime sentTimeStamp;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "event_id", nullable = false)
	@JsonBackReference
	private Event event;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "attendee_id", nullable = false)
	@JsonBackReference
	private Attendee attendee;
}
