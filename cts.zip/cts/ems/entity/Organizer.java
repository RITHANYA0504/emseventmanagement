package com.cts.ems.entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.*;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "organizer_tbl")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Organizer {

	@Id
	String userId;

	@OneToOne
	@MapsId
	@JoinColumn(name = "organizer_id")
	User user;

	@OneToMany(mappedBy = "organizer", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<Event> eventsOrganized;
}

