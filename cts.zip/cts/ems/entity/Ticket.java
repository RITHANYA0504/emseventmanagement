package com.cts.ems.entity;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
 
import java.time.LocalDateTime;
 
import org.apache.commons.lang3.RandomStringUtils;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
 
@Entity
@Table(name="ticket_tbl")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Ticket{
 
    @Id
    private String ticketId;
    @SuppressWarnings("deprecation")
	@PrePersist
    public void generatedId() {
    	if(ticketId == null) {
    		ticketId = RandomStringUtils.randomAlphanumeric(3);
    		ticketId += RandomStringUtils.randomNumeric(2);
    	}
    }
 
    @CreationTimestamp
    private LocalDateTime bookingDate;
    @UpdateTimestamp
    private LocalDateTime updateDate;
    @NotNull(message = "Status is required")
    private String status;
 
 
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_id",nullable = false)
    @JsonIgnore
    private Payment payment;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id",nullable = false)
    @JsonIgnore
    private Event event;
 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attendee_id",nullable = false)
    @JsonIgnore
    private Attendee attendee;
}