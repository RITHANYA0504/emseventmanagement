package com.cts.ems.controller;
 
import java.util.List;
import java.util.Optional;
 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.cts.ems.dto.*;
import com.cts.ems.entity.*;
import com.cts.ems.exception.*;
import com.cts.ems.service.AttendeeServiceImp;
import com.cts.ems.service.OrganizerServiceImp;
import com.cts.ems.service.UserServiceImp;

import lombok.RequiredArgsConstructor;
 
 
@RequestMapping("/user")
@RestController
@RequiredArgsConstructor
public class UserController {
	
	private final UserServiceImp uServ;
	
	private final OrganizerServiceImp oServ;
	
	private final AttendeeServiceImp aServ;

//------------------------User----------------------

//Creating User
	@PostMapping("/signup")
	public UseruserDto signUp(@RequestBody UseruserDto userDto) throws UserException {
		return uServ.addUser(userDto);
	}
//Login using Username and password
	@GetMapping("/login")
	public ResponseEntity<UseruserDto> login(@RequestParam String name,@RequestParam String password) throws UserException {
		LoginUserDto logins=new LoginUserDto();
		logins.setName(name);
		logins.setPassword(password);
		UseruserDto user= uServ.login(logins);
		return ResponseEntity.ok(user);
	}
//Deleting User
	@DeleteMapping("/deleteaccount/{id}")
	public ResponseEntity<String> deleteAccount(@PathVariable("id") String id) throws UserException {
	    return ResponseEntity.ok(uServ.deleteUser(id));
	}
 
	
//get User By User id
	@GetMapping("/finduserbyid")
	public UseruserDto viewAccount(@RequestParam String id) throws UserException {
		return uServ.getUser(id);
	}
//Update User by User Body
	@PutMapping("/updateaccount/{user_id}")
	public User updateAccount(@PathVariable("user_id") String user_id,@RequestBody UseruserDto userDto) throws UserException {
		return uServ.updateUser(user_id,userDto);
	}
//Forgot Password 
	@GetMapping("/forgotpassword")
	public User forgotPassword(@RequestParam String userName,@RequestParam String email,@RequestParam String number,@RequestParam String newPassword) throws UserException {
		return uServ.forgotPassword(userName, email, number, newPassword);
	}
//get All User
	@GetMapping("/getalluser")
	public List<UseruserDto> getAllUser() throws UserException{
		return uServ.getAllUser();
	}
//update UserName using User Id
	@PutMapping("/updateusername/{id}/{name}")
	public User updateUserName(@PathVariable("id") String id,@PathVariable("name") String name) throws UserException {
		return uServ.updateName(id, name);
	}
//update User Email by using User Id
	@PutMapping("/updateemail/{id}/{email}")
	public User updateUserEmail(@PathVariable("id") String id,@PathVariable("email") String email) throws UserException {
		return uServ.updateEmail(id, email);
	}
//update User Contact Number by using User Id
	@PutMapping("/updatenumber/{id}/{number}")
	public User updateUserContactNumber(@PathVariable("id") String id,@PathVariable("number") String number) throws UserException {
		return uServ.updateContactNumber(id, number);
	}
//update User age by using User Id
	@PutMapping("/updateage/{id}/{age}")
	public User updateUserAge(@PathVariable("id") String id,@PathVariable("age") Integer age) throws UserException {
		return uServ.updateAge(id, age);
	}
//update User gender by using User Id
	@PutMapping("/updategender/{id}/{gender}")
	public User updateUserGender(@PathVariable("id") String id,@PathVariable("gender") String gender) throws UserException {
		return uServ.updateGender(id, gender);
	}
 
 
//-----------------------Attendee----------------------------------------
//get Attendee by using Attendee id
	@GetMapping("/getattendeebyid/{id}")
	public AttendeeUserDto getAttendeeById(@PathVariable("id") String id) throws AttendeeException{
		return aServ.getAttendeeById(id);
	}
 
//get all attendee	
	@GetMapping("/allattendees")
	public List<AttendeeUserDto> getAllAttendees() {
	    return aServ.getAllAttendees();
	}
//add membership status
	@PostMapping("/addmembership/{id}")
	public String addMemberShip(@PathVariable("id") String userId) throws AttendeeException {
		return aServ.addMemberShip(userId);
	}
	
//get all preferenece
	@GetMapping("/getpreference/{id}")
	public List<String> getPreference(@PathVariable("id") String userId)throws AttendeeException{
		return aServ.getPreference(userId);
	}
//----------------------------Organizer-------------------------------------------
//get Organizer by using organizer id
	@GetMapping("/getorganizerbyid/{id}")
	public OrganizerUserDto getOrganizerById(@PathVariable("id") String id) throws OrganizerException {
	    return oServ.getOrganizerById(id);
	}
//get All Organizer
	@GetMapping("/getallorganizer")
	public List<OrganizerUserDto> getAllOrganizers() throws OrganizerException {
	    return oServ.getAllOrganizers();
	}
//delete Organizer by Organizer Id
	@DeleteMapping("/deleteorganizerbyid/{id}")
    public String deleteOrganizerById(@PathVariable("id") String id) throws OrganizerException, EventException {
        return oServ.deleteOrganizerById(id);
    }

//get all payment by organizer id
	@GetMapping("/getpaymentsbyorganizerid/{organizerId}/{eventId}")
	public List<PaymentUserDto> getAllPayments(@PathVariable("organizerId") String organizerId,@PathVariable("eventId") String eventId) throws OrganizerException{
		return oServ.getAllPayments(organizerId, eventId);
	}
}