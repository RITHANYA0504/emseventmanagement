package com.cts.ems.controller;
 
import com.cts.ems.dto.ShowAllTicketsDto;
import com.cts.ems.dto.TicketEventDto;
import com.cts.ems.dto.TicketRequestDto;
import com.cts.ems.dto.TicketResponseDto;
import com.cts.ems.dto.TicketShareResponseDto;
import com.cts.ems.service.TicketServiceImp;
 
import lombok.RequiredArgsConstructor;
 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
 
import java.util.List;
 
@RestController
@RequestMapping("/ticket")
@RequiredArgsConstructor
public class TicketController {
 
    private final TicketServiceImp ticketServiceImp;
 
    @GetMapping("/showalltickets")
    public List<ShowAllTicketsDto>  showAllTickets(){
        return ticketServiceImp.showAllTickets();
    }

    @GetMapping("/showalleventtickets/{eventId}")
    public List<ShowAllTicketsDto>  showAllTicketsByEvent(@PathVariable String eventId){
        return ticketServiceImp.showAllTicketsByEvent(eventId);
    }
    @GetMapping("/showallattendeetickets/{attendeeId}")
    public List<ShowAllTicketsDto>  showAllTicketsByAttendee(@PathVariable String attendeeId){
        return ticketServiceImp.showAllTicketsByEvent(attendeeId);
    }
 
    
    @PostMapping("/addticket")
    public ResponseEntity<TicketResponseDto> bookTicket (@RequestBody TicketRequestDto requestDto){
    	TicketResponseDto response = ticketServiceImp.bookTicket(requestDto);
    	return  ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
 
    @PutMapping("/cancelticket/{ticketId}")
    public ResponseEntity<TicketResponseDto> cancelTicket(@PathVariable String ticketId) {
    	TicketResponseDto response = ticketServiceImp.cancelTicket(ticketId);
    	return  ResponseEntity.status(HttpStatus.CREATED).body(response);
  }
    @GetMapping("/getticketdetails/{ticketId}")
    public ResponseEntity<TicketResponseDto> getTicketDetails(@PathVariable String ticketId){
    	TicketResponseDto response = ticketServiceImp.getTicketDetails(ticketId);
    	return  ResponseEntity.status(HttpStatus.OK).body(response);
    }

 
    @GetMapping("/getbookingstatus/{ticketId}")
    public  ResponseEntity<String> getBookingStatus(@PathVariable String ticketId) {
    	String status = ticketServiceImp.getBookingStatus(ticketId);
    	return ResponseEntity.status(HttpStatus.OK).body(status);
    }

    @GetMapping("/getticketbyeventattendee/{eventId}/{attendeeId}")
    public ResponseEntity<TicketResponseDto> getTicketDetailsByEventAndAttendee(@PathVariable String eventId,@PathVariable String attendeeId) {
    	TicketResponseDto response=  ticketServiceImp.getTicketDetailsByEventAndAttendee(eventId,attendeeId);
    	return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/shareticket/{ticketId}")
    public ResponseEntity<TicketShareResponseDto> shareTicket(@PathVariable String ticketId) {
    	TicketShareResponseDto response= ticketServiceImp.shareTicket(ticketId);
    	return ResponseEntity.status(HttpStatus.OK).body(response);
    }
 
    
    @GetMapping("/getattendedevents/{attendeeId}")
    public ResponseEntity<List<TicketEventDto>> getAttendedEvents(@PathVariable String attendeeId) {
    	List<TicketEventDto> response= ticketServiceImp.getAttendedEvents(attendeeId);
    	return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @PutMapping("/autorefundwaitlist")
    public void autoRefundWaitlist() {
    	ticketServiceImp.autoRefundWaitlist(); 
  }
    @GetMapping("/getexpiredticket")
    public ResponseEntity<List<TicketResponseDto>> getExpiredTicket() {
    	List<TicketResponseDto> response= ticketServiceImp.getExpiredTicket();
    	return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}