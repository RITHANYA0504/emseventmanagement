package com.cts.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.cts.ems.dto.PaymentResponseDto;
import com.cts.ems.entity.Payment;
import com.cts.ems.service.EventServiceImp;
import com.cts.ems.service.PaymentServiceImp;

import lombok.RequiredArgsConstructor;

import java.util.List;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {
	
	private final PaymentServiceImp paymentService;

	@GetMapping("/getall")
	public List<Payment> getAllPaymentDTo() {
		List<Payment> paymentList = paymentService.getAllPayment();
		return paymentList;
	}

	@GetMapping("/getbyid/{paymentId}")
	public ResponseEntity<Payment> getPaymentById(@PathVariable String paymentId) {
		Payment payment = paymentService.getPaymentById(paymentId);
		return ResponseEntity.status(HttpStatus.OK).body(payment);
	}



	@GetMapping("/track/{paymentId}")
	public ResponseEntity<String> trackPaymentStatus(@PathVariable String paymentId) {
		String status = paymentService.trackPaymentStatus(paymentId);
		return ResponseEntity.status(HttpStatus.OK).body(status);
	}

	@GetMapping("/generatereport/{paymentId}")
	public ResponseEntity<PaymentResponseDto> generateReport(@PathVariable String paymentId) {
		PaymentResponseDto report = paymentService.generateReport(paymentId);
		return ResponseEntity.status(HttpStatus.OK).body(report);
	}

	@GetMapping("/checksuccess/{paymentId}")
	public boolean isPaymentSuccessful(@PathVariable String paymentId) {
		boolean isSuccessfull = paymentService.isPaymentSuccessful(paymentId);
		return isSuccessfull;
	}

	@GetMapping("/getallbyattendeeid/{attendeeId}")
	public List<PaymentResponseDto> getPaymentsByAttendeeId(@PathVariable String attendeeId) {
		List<PaymentResponseDto> paymentList = paymentService.getPaymentsByAttendeeId(attendeeId);
		return paymentList;
	}

	@GetMapping("/getallbyeventid/{eventId}")
	public List<PaymentResponseDto> getPaymentsByEventId(@PathVariable String eventId) {
		List<PaymentResponseDto> paymentList = paymentService.getPaymentsByEventId(eventId);
		return paymentList;
	}

	@PutMapping("/refund/{paymentId}")
	public ResponseEntity<String> refundPayment(@PathVariable String paymentId) {
		paymentService.refundPayment(paymentId);
		return ResponseEntity.ok("payment refunded");
	}
}
