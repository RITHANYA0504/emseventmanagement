package com.cts.ems.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cts.ems.dto.EventEventDto;
import com.cts.ems.dto.EventResponseDto;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.OrganizerException;
import com.cts.ems.exception.UserException;
import com.cts.ems.service.EventServiceImp;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("event")
@RequiredArgsConstructor
public class EventController {	
	
	
	private final EventServiceImp eventServ;
	
	@GetMapping("/geteventbyid/{id}")
	public EventEventDto getEventById(@PathVariable("id") String id) throws EventException  {
		EventEventDto e= eventServ.getEventById(id);
		return e;
	}
	
	@PostMapping("/addevent")
	public EventEventDto addEvent(@RequestBody EventEventDto e) throws UserException, EventException, OrganizerException {
		
		return eventServ.addEvent(e);
	}
	
	@PutMapping("/updateevent/{eventId}")
	public EventEventDto updateEvent(@PathVariable("eventId") String eventId,@RequestBody EventEventDto e) throws  EventException {
		
		return eventServ.updateEvent(eventId, e);
	}
	
	
//	
	@GetMapping("/getallevents")
	public ResponseEntity<List<EventResponseDto>> getAllEvent() throws EventException {
		
		List<EventResponseDto> res = eventServ.getAllEvent();
		
		return new ResponseEntity<List<EventResponseDto>>(res, HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteeventbyid/{id}")
	public EventEventDto deleteEventById(@PathVariable("id") String id) throws EventException {
		 return eventServ.deleteById(id);
	}
	
	
	
	@GetMapping("geteventbycategory/{cat}")
	public List<EventEventDto> getEventByCategory(@PathVariable("cat")String cat){
		 return eventServ.getEventByCategory(cat);
	}
	@GetMapping("/geteventbyorganizer/{id}")
	public List<EventEventDto> getEventByOrganizerId(@PathVariable("id") String orgId) throws EventException, OrganizerException{
		return eventServ.getEventByOrganizerId(orgId);
	}
	
	 @GetMapping("/geteventamountlessthan/{amt}")
	 public List<EventEventDto> getEventByAmount(@PathVariable("amt") Double amt){
		 return eventServ.getEventByAmount(amt);
	 }
}
