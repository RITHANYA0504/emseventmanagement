package com.cts.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ems.dto.FeedbackRequestDTO;
import com.cts.ems.dto.FeedbackResponseDTO;
import com.cts.ems.entity.Feedback;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.FeedbackException;
import com.cts.ems.service.EventServiceImp;
import com.cts.ems.service.FeedbackServiceImp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/feedback")
@RequiredArgsConstructor
public class FeedbackController {
	
		private final FeedbackServiceImp fServ;
		
		@GetMapping("/getall")
		public List<FeedbackResponseDTO> getAllFeedback(){
			return fServ.getAllFeedback();
		}
		
		
		@GetMapping("/getbyId/{id}")
		public ResponseEntity<FeedbackResponseDTO> getFeedbackById(@PathVariable("id")String feedbackId) {
			FeedbackResponseDTO fResponse = fServ.getFeedbackById(feedbackId);
			
			if(fResponse!=null) {
				return ResponseEntity.ok(fResponse);
			}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
		}
		
		@PostMapping("/add")
		public FeedbackResponseDTO addFeedback(@RequestBody FeedbackRequestDTO f) throws EventException {
			return fServ.addFeedback(f);
		}
		
		
		@PutMapping("/updatecomment/{id}/{comment}")
		public ResponseEntity<String> updatCommentById(@PathVariable("id")String id,@PathVariable("comment")String comment) {
			FeedbackResponseDTO fResponse= fServ.updateCommentById(id, comment);
			if(fResponse!=null) {
				return ResponseEntity.ok("Updated Comment Feedback:\n"+fResponse);
			}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Sorry");
			}
		}
		
		@PutMapping("/updaterating/{id}/{rating}")
		public ResponseEntity<String> updateRatingById(@PathVariable("id")String id,@PathVariable("rating")int rating) {
			FeedbackResponseDTO fResponse= fServ.updateRatingById(id, rating);
			if(fResponse!=null) {
				return ResponseEntity.ok("Updated Rating Feedback:\n"+fResponse);
			}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Sorry");
			}
		}
		
		@DeleteMapping("/delete/{id}")
		public ResponseEntity<String> deleteFeedbackById(@PathVariable("id")String id) {
			String f= fServ.deleteFeedbackById(id);
			if(f!=null) {
				return ResponseEntity.ok(f);
			}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
			
		}
		
}
