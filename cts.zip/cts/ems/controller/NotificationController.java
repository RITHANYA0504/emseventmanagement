package com.cts.ems.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.cts.ems.dto.NotificationRequestDTO;
import com.cts.ems.dto.NotificationResponseDTO;
import com.cts.ems.exception.AttendeeException;
import com.cts.ems.exception.EventException;
import com.cts.ems.exception.NotificationException;
import com.cts.ems.service.NotificationServiceImp;
 
@RestController
@RequestMapping("/notifications")
public class NotificationController {
 
    @Autowired
    private NotificationServiceImp notificationService;
 
    @GetMapping("/getAllNotifications")
    public ResponseEntity<List<NotificationResponseDTO>> getAllNotifications() {
        List<NotificationResponseDTO> notifications = notificationService.findAllNotification();
        return ResponseEntity.ok(notifications);
    }
    @GetMapping("/getNotificationById/{nid}")
    public NotificationResponseDTO getNotificationById(@PathVariable String nid) throws NotificationException
    {
    		return notificationService.getNotificationById(nid); 		
    }
 
    @PostMapping("/addNotification")
    public NotificationResponseDTO addNotification(@RequestBody NotificationRequestDTO r) {
        return notificationService.addNotification(r);
    }

 
 
    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateNotification(@PathVariable("id") String notificationId,@RequestBody NotificationRequestDTO updatedRequestDTO) {
    	try {
    		NotificationResponseDTO updatedNotification = notificationService.updateNotificationById(notificationId, updatedRequestDTO);
    		return ResponseEntity.ok("Notification updated successfully");
    	} 
    	catch (NotificationException e) 
    	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("NotificationException: " + e.getMessage());
    	} 
    	catch (EventException e) 
    	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("EventException: " + e.getMessage());
    	} 
    	catch (AttendeeException e) 
    	{
    		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("AttendeeException: " + e.getMessage());
    	} 
    }

 
 
 
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteNotificationById(@PathVariable("id") String notificationId) throws NotificationException
    {
	    String result = notificationService.deleteNotificationById(notificationId);
	    if ("Deleted Successfully".equals(result)) 
	    {
	    return ResponseEntity.ok(result);
	    } 
	    else 
	    {
	    	return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
	    }
    }
}