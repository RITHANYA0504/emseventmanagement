package com.cts.ems.exception;

public class NotificationException extends RuntimeException{
	
	public NotificationException(String msg)
	{
		super(msg);
	}
	
	

}
