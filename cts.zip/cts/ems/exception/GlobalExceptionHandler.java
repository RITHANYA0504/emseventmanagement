package com.cts.ems.exception;
 
import java.time.LocalDateTime;
 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
 
import com.cts.ems.model.ErrorInfo;
 
import jakarta.servlet.http.HttpServletRequest;
 
@RestControllerAdvice
public class GlobalExceptionHandler {
 
	@ExceptionHandler(TicketException.class)
	public ResponseEntity<ErrorInfo> TicketExceptionHandler(TicketException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);
	}
 
	@ExceptionHandler(AttendeeException.class)
	public ResponseEntity<ErrorInfo> AttendeeExceptionHandler(AttendeeException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);	}
 
	@ExceptionHandler(EventException.class)
	public ResponseEntity<ErrorInfo> EventExceptionHandler(EventException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);	}
 
	@ExceptionHandler(NotificationException.class)
	public ResponseEntity<ErrorInfo> NotificationExceptionHandler(NotificationException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);	}
 
	@ExceptionHandler(FeedbackException.class)
	public ResponseEntity<ErrorInfo> FeedbackExceptionHandler(FeedbackException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);
	}
 
	@ExceptionHandler(PaymentException.class)
	public ResponseEntity<ErrorInfo> PaymentExceptionHandler(PaymentException e, HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ErrorInfo> UserExceptionHandler(UserException e,HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);	}
	
	@ExceptionHandler(OrganizerException.class)
	public ResponseEntity<ErrorInfo> OrganizerExceptionHandler(OrganizerException e,HttpServletRequest url) {
		ErrorInfo errorInfo = new ErrorInfo(e.getMessage(), LocalDateTime.now(), url.getRequestURI());
	    return new ResponseEntity<>(errorInfo, HttpStatus.BAD_REQUEST);	
	
	}
}
 