package com.cts.ems.exception;

public class OrganizerException extends RuntimeException{

	public OrganizerException(String msg) {
		super(msg);
	}
}
