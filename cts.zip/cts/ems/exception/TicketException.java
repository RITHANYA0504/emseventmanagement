package com.cts.ems.exception;

public class TicketException extends RuntimeException {
    public TicketException(String message) {
        super(message);
    }
}
