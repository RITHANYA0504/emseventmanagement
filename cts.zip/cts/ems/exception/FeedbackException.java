package com.cts.ems.exception;

public class FeedbackException extends  RuntimeException {
	
    public FeedbackException(String message) {
        super(message);
    } 

}
