package com.cts.ems.exception;

public class AttendeeException extends RuntimeException {
    public AttendeeException(String message) {
        super(message);
    }
}
