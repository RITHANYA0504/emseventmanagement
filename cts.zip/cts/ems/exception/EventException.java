package com.cts.ems.exception;

public class EventException extends RuntimeException {
	public EventException(String s) {
		super(s);
	}
}

